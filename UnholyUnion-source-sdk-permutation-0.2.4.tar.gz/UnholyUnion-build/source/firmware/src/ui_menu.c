/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments */
/* Felucca menu (HOME held): its rows in tabs (1.0.5: DISPLAY CONTROL AUDIO SYSTEM; 1.2: MIDI before SYSTEM; ALGORITHM
 * between them, PRESETS within one; no scrolling), the rows in menu_items.c (the settings, shared with the editor's
 * MENU_DESC / MENU_SET; 1.2: TUNE and MIDI IN, the project's). No BACK row: HOME closes it (ui_input.c). The two-valued
 * rows are bits of ui_prefs (MENU_FLAGS). PRESETS scrolls from ABOUT through all credits (OCT- back to the tabs).
 * ui.menu: 1 the tabs, 2 ABOUT (information and credits), 3 INFO (1.2: the device's state, the old SYSTEM page's USB and
 * CPU readings). */
/* ------------------------------------------------------------ menu --- */
/* (the rows, their values and names, usb_serial_apply: menu_items.c) */

/* The Ritual Room: QR version 5, correction M, four-module quiet zone.
 * One row per 64-bit word; fixed matrix requires no encoder or runtime RAM. */
static const uint64_t ABOUT_QR[37] = {
    0x1FDB75D07Full,
    0x10466A1641ull,
    0x175579F15Dull,
    0x17464E6F5Dull,
    0x17509C815Dull,
    0x104944E941ull,
    0x1FD555557Full,
    0x001C091900ull,
    0x07D1741C7Dull,
    0x0C8C23C5ADull,
    0x1DDF920DD0ull,
    0x11A8E1243Eull,
    0x1F6FD36B73ull,
    0x0096BF4205ull,
    0x1BBF33DED8ull,
    0x119AFF249Full,
    0x054CA907F1ull,
    0x0C9956FBA9ull,
    0x1A8409B440ull,
    0x11717CA494ull,
    0x05674AAACEull,
    0x02359C073Bull,
    0x1BA944D8E2ull,
    0x01BD19F421ull,
    0x0D59FC6177ull,
    0x06CC23F409ull,
    0x197BF27859ull,
    0x19C8A17B85ull,
    0x1DFFC26C51ull,
    0x031EAF6300ull,
    0x1D5733A07Full,
    0x1B126E8541ull,
    0x1DFC21ED5Dull,
    0x096154D75Dull,
    0x100C4FDF5Dull,
    0x112D38A041ull,
    0x1F165AE17Full,
};
static void draw_about_qr(int32_t x, int32_t y)
{
    cv_rect(x, y, 90, 90, UI_QR_LIGHT);
    for (uint32_t row = 0; row < 37u; row++)
        for (uint32_t col = 0; col < 37u; col++)
            if ((ABOUT_QR[row] >> col) & 1u)
                cv_rect(x + 8 + (int32_t)col * 2, y + 8 + (int32_t)row * 2, 2, 2, UI_QR_DARK);
}

/* All notices are in flash. Wrap at the font's actual width, without dropping URL
 * characters; the same layout computes the scroll limit and draws clipped bands.
 * Mixed case here (long text); S throughout, the title in L. */
#define MENU_DOC_H 196                                /* the document: screen rows 24..220 */
enum { MC_TEXT, MC_TITLE, MC_URL };
typedef struct { const char *text; uint8_t kind; } menu_credit_t;
static const menu_credit_t MENU_CREDITS[] = {
    {"SAINT FELUCCA", MC_TITLE},
    {"Our foundation: Leo Kuroshita, Hugelton Instruments and the community.", MC_TEXT},
    {"https://github.com/hugelton/Felucca", MC_URL},
    {"", MC_TEXT},
    {"SAINT JANGADA", MC_TITLE},
    {"zednaked and contributors: the drone that keeps the vigil. GPL-3.0.", MC_TEXT},
    {"https://github.com/zednaked/jangada", MC_URL},
    {"", MC_TEXT},
    {"ARCHANGEL CHANCE", MC_TITLE},
    {"Cyma Forma + Bambounou's RND: inspiration for Immaculate Permutation. No RND code or assets copied.", MC_TEXT},
    {"https://www.cymaforma.com/rnd-synth", MC_URL},
    {"", MC_TEXT},
    {"H\xFCgelton Instruments", MC_TITLE},  /* Felucca's own: above; these are ours too */
    {"Leo Kuroshita", MC_TEXT},
    {"CrispyZebra (PHASE waveforms), the DRUM voices, the Sample Pack: GPL-3.0", MC_TEXT},
    {"Fukiai icon font: MIT", MC_TEXT},
    {"https://github.com/hugelton", MC_URL},
    {"", MC_TEXT},
    {"KLATTSCH", MC_TITLE},
    {"Tony Gies / MIT", MC_TEXT},
    {"https://github.com/tgies/klattsch", MC_URL},
    {"", MC_TEXT},
    {"DAISYSP", MC_TITLE},
    {"Electrosmith, Emilie Gillet", MC_TEXT},
    {"MIT", MC_TEXT},
    {"https://github.com/electro-smith/DaisySP", MC_URL},
    {"", MC_TEXT},
    {"DEXED + MSFA", MC_TITLE},
    {"Pascal Gauthier, Google Inc.", MC_TEXT},
    {"msfa: Apache-2.0, Dexed: GPL-3.0", MC_TEXT},
    {"https://github.com/asb2m10/dexed", MC_URL},
    {"", MC_TEXT},
    {"RINGS", MC_TITLE},
    {"Emilie Gillet / MIT", MC_TEXT},
    {"https://github.com/pichenettes/eurorack", MC_URL},
    {"", MC_TEXT},
    {"INTER TIGHT", MC_TITLE},
    {"The Inter Project Authors", MC_TEXT},
    {"SIL Open Font License 1.1", MC_TEXT},
    {"https://github.com/rsms/inter-tight", MC_URL},
    {"", MC_TEXT},
    {"VSCO-2 CE + VCSL", MC_TITLE},
    {"Versilian Studios / CC0 1.0", MC_TEXT},
    {"https://github.com/sgossner/VSCO-2-CE", MC_URL},
    {"https://github.com/sgossner/VCSL", MC_URL},
    {"", MC_TEXT},
    {"VOICE", MC_TITLE},
    {"Dennis H. Klatt (1980)", MC_TEXT},
    {"https://doi.org/10.1121/1.383940", MC_URL},
    {"Hillenbrand, Getty, Clark and Wheeler (1995)", MC_TEXT},
    {"https://doi.org/10.1121/1.411872", MC_URL},
};

static int32_t menu_text(const char *s, int32_t y, uint16_t col, int draw)
{
    while (*s) {
        char line[64];
        uint32_t n = 0, space = 0, take, prev = 0;
        int32_t pen = 0;                                 /* 1/16 px, as text_w adds it up */
        while (s[n] && n < sizeof line - 1u) {
            uint32_t c = (uint8_t)s[n];
            line[n] = s[n];
            line[n + 1u] = 0;
            pen += (prev ? kern(&AF_S, prev, c) : 0) + AF_S.g[glyph(&AF_S, c)].adv;
            prev = c;
            if ((pen + 8) >> 4 > 226)
                break;
            if (s[n] == ' ')
                space = n;
            n++;
        }
        take = s[n] && space ? space : n;
        if (!take) take = 1;                         /* progress even for an unusually wide glyph */
        line[take] = 0;
        if (draw && y + AF_S.h > 0 && y < MENU_DOC_H)
            cv_text(6, y, &AF_S, line, col);
        y += 18;
        s += take;
        while (*s == ' ') s++;
    }
    return y;
}

static int32_t menu_document(int32_t y, int draw)
{
    uint32_t i;
    if (draw) {
        cv_text(6, y + 2, &AF_L, "UnholyUnion", T_THEME);
        cv_rect(218, y + 6, 4, 24, T_THEME);
        cv_rect(212, y + 12, 16, 4, T_THEME);
        cv_text(6, y + 38, &AF_S, "Four voices. One congregation.", T_TEXT);
        cv_text(6, y + 58, &AF_M, FELUCCA_VERSION, T_THEME);
        cv_text_r(232, y + 61, &AF_S, __DATE__, T_MID, T_BG);
        cv_text(6, y + 82, &AF_S, "Felucca + Jangada", T_TEXT);
        cv_text(6, y + 100, &AF_S, "Built on sacred shoulders", T_TEXT);
        cv_text(6, y + 118, &AF_S, "GPL-3.0-only", T_TEXT);
        cv_text(6, y + 138, &AF_S, "The Ritual Room", T_MID);
        cv_text(6, y + 156, &AF_S, "Scan for sermons", T_MID);
        cv_text(6, y + 180, &AF_S, "Saints below", T_MID);
        draw_about_qr(142, y + 106);
    }
    y = menu_text("OUR PATRON SAINTS", y + 216, T_THEME, draw) + 8;
    for (i = 0; i < NELEM(MENU_CREDITS); i++) {
        const menu_credit_t *c = &MENU_CREDITS[i];
        const char *text = c->text;
        /* Display host/path once; the full source URL stays in the flash table. */
        if (c->kind == MC_URL && str_len(text) >= 8u && !memcmp(text, "https://", 8))
            text += 8;
        if (!text[0]) y += 8;
        else y = menu_text(text, y, c->kind == MC_TITLE ? T_THEME : c->kind == MC_URL ? T_MID : T_TEXT, draw);
    }
    y = menu_text("LICENSES + SOURCE", y + 12, T_THEME, draw);
    y = menu_text("DRUM + own samples: GPL-3.0-only", y, T_TEXT, draw);
    y = menu_text("Fonts and icons: their licences travel with the source and the release files.", y, T_TEXT, draw);
    y = menu_text("NO WARRANTY", y, T_TEXT, draw);
    y = menu_text("Full notices in source:", y + 8, T_TEXT, draw);
    y = menu_text("github.com/hugelton/Felucca", y, T_MID, draw);
    return y + 4;
}
static int32_t menu_scroll_max(void)
{
    int32_t h = menu_document(0, 0);
    return h > MENU_DOC_H ? h - MENU_DOC_H : 0;
}

static void menu_dots(void);
/* the menu's header (0..24): its icon and title, the REC mark, the way back (the tabs: HOME CLOSE before the dots) */
static void menu_head(void)
{
    cv_begin(240, H_HEAD, T_BG);
    GFX_HOOK_ALIGN(0, HEAD_MY + AF_M_CAP_Y, 0, HEAD_MY + AF_M_CAP_Y + AF_M_CAP_H, AL_V, "header icon on its title's line");
    cv_icon_mid(8, H_HEAD / 2, 16, ui.menu >= 2 ? ICON_X_INFO : ICON_X_COG, T_THEME, T_BG);   /* (as draw_head's) */
    GFX_HOOK_ALIGN(0, 0, 0, H_HEAD, AL_V, "header text on its middle");
    cv_text(30, HEAD_MY, &AF_M, ui.menu == 3 ? "INFO" : ui.menu == 2 ? "SAINTS / SOURCE" : "MENU", T_TEXT);
    if (ui.menu >= 2) {                               /* the way back at the right, the REC mark before it (then */
        const char *w = song.rec ? 0 : "BACK";        /* the keycap goes without its word: no room for both) */
        int32_t x = 232 - kh_w(KC_OCTDN, w);
        GFX_HOOK_ALIGN(0, 0, 0, H_HEAD, AL_V, "header text on its middle");
        cv_key_hint(x, HALF_UP(H_HEAD - KC_H), KC_OCTDN, w, 1, T_BG);
        draw_rec_mark(x - 20, T_BG);
    } else {
        int32_t x = 232 - (12 + (int32_t)(MTAB_COUNT - 1u) * 8) - 8 - kh_w(KC_HOME, "CLOSE");   /* (menu_dots' left) */
        GFX_HOOK_ALIGN(0, 0, 0, H_HEAD, AL_V, "header text on its middle");
        cv_key_hint(x, HALF_UP(H_HEAD - KC_H), KC_HOME, "CLOSE", 1, T_BG);
        draw_rec_mark(x - 20, T_BG);
        menu_dots();
    }
    cv_blit(0, Y_HEAD);
}

/* The page (1.0.5): the tabs across the top, the rows of the one shown below, the key hints at the bottom.
 *   header   0..24  the cog and MENU, the REC mark, HOME CLOSE, the tabs as dots at the right (the one shown a THEME
 *                   pill)
 *   tabs    29..53  a 24 px cushion per tab: its icon alone (SURF, MID); the one shown wider, with its name (ACCENT,
 *                   INK; S, LARGE M), MT_GAP between any two. With ANIM ON the cushions grow and shrink into place
 *                   (mt_follow), the gaps kept
 *   rows    59..    one SURF panel (FLAT; LINE: none, a rule under the tabs), a row a label and its value, 1 px rules
 *                   between them; the selected row THEME with INK, as the browser's. A value THEME (M) at the right,
 *                   ON / OFF as a switch, COLOR its palette's five colours, CALIBRATION and ABOUT a chevron (OCT+
 *                   opens them); the labels in M too (a list's rows). LARGE: 28 px rows (a tab of up to 5)
 *   keys   224      ALGO TAB, PRESETS ROW, OCT-/+ VALUE (any of KNOB 1..4 too; CALIBRATION, ABOUT: OCT+ OPEN). HOME
 *                   CLOSE is in the header: the four would not fit in S (cv_key_row drops words, from the last)
 * Drawn in two bands (the canvas holds 124 rows) split in a gap between two rows; while the tabs slide only their
 * strip (24..58) is drawn again */
static const uint16_t MTAB_ICON[MTAB_COUNT] = {ICON_X_EYE, ICON_X_KNOB, ICON_X_SPEAKER, ICON_MIDI, ICON_X_COG};
#define MT_Y 29                                        /* the tab bar */
#define MT_H 24
#define MT_IW 26                                       /* a cushion with its icon alone (the icon centred in it; 1.2, five
                                                        * tabs: 26, up to 1.1.5 32) */
#define MT_NX 24                                       /* the name's pen in the one shown; 10 px after it */
#define MT_X0 6
#define MT_X1 234
#define MT_GAP 5                                       /* between two tabs, always (the bar centred in MT_X0..MT_X1; 1.2, five
                                                        * tabs: 5, up to 1.1.5 8) */
#define MT_ONE 64                                      /* mt.pos per tab */
#define MP_Y 59                                        /* the rows' panel */
#define MP_PAD 3
#define MR_X 8                                         /* a row */
#define MR_W 224
#define MR_LX 16                                       /* its label */
#define MR_VR 224                                      /* its value's right edge */
#define MK_Y 224                                       /* the key hints */
static int menu_large(void) { return (ui_prefs & PREF_LARGE) != 0u; }
static uint32_t menu_tab(void) { return MI_TAB[ui.menu_sel % MI_COUNT]; }
/* the shown tab's rows: 24 px (LARGE 28, a tab of up to 5 rows), 2 px apart (a tab of 6: 1 px, its panel then ends
 * 6 px above the key hints as the others do; the rule between two rows is that gap row; 1.2, a tab of 7: 21 px rows
 * 1 px apart, its panel then ends 4 px lower, LARGE too; 1.3, a tab of 8: 18 px rows 1 px apart, the same end) */
static int32_t mr_h(void)
{
    uint32_t n = mtab_rows(menu_tab());
    return n > 7u ? 18 : n > 6u ? 21 : menu_large() && n <= 5u ? 28 : 24;
}
static int32_t mr_gap(void) { return mtab_rows(menu_tab()) <= 5u ? 2 : 1; }
static int32_t mr_y(uint32_t k) { return MP_Y + MP_PAD + (int32_t)k * (mr_h() + mr_gap()); }

/* the tab bar's place: the tab shown at pos tab * MT_ONE; with ANIM ON it follows in halving steps, a frame each
 * (a frame missed, as when the menu opens: it snaps, as ui_graph.c pr_follow) */
static struct { int16_t pos; uint32_t frame; } mt;
static void mt_follow(void)
{
    int32_t want = (int32_t)menu_tab() * MT_ONE, d = want - mt.pos;
    if (ui.frame != mt.frame + 1u || (ui_prefs & PREF_ANIM_OFF) || (d < 3 && d > -3))
        mt.pos = (int16_t)want;
    else
        mt.pos = (int16_t)(mt.pos + d / 2);
    mt.frame = ui.frame;
}
static const aafont_t *mt_font(void) { return menu_large() ? &AF_M : &AF_S; }
/* the tabs at the place mt.pos, MT_GAP apart, centred: each one's share of the shown look (0 .. MT_ONE), x, width */
static void mt_layout(int32_t *a, int32_t *x, int32_t *w)
{
    uint32_t k;
    int32_t tot = 0, cum = 0;
    for (k = 0; k < MTAB_COUNT; k++) {
        int32_t d = mt.pos - (int32_t)k * MT_ONE;
        a[k] = MT_ONE - (d < 0 ? -d : d);
        if (a[k] < 0) a[k] = 0;
        w[k] = MT_IW + (MT_NX - MT_IW + text_w(mt_font(), MTAB_NAME[k]) + 10) * a[k] / MT_ONE;
        tot += w[k];
    }
    cum = MT_X0 + HALF_UP(MT_X1 - MT_X0 - tot - (int32_t)(MTAB_COUNT - 1u) * MT_GAP);   /* (the bar centred) */
    for (k = 0; k < MTAB_COUNT; k++) {                 /* the same gap between every two, sliding too */
        x[k] = cum;
        cum += w[k] + MT_GAP;
    }
}
static void menu_tabs(void)                            /* (in screen rows: cv_oy set by the caller) */
{
    int32_t a[MTAB_COUNT], x[MTAB_COUNT], w[MTAB_COUNT];
    uint32_t k;
    mt_layout(a, x, w);
    if (ux.style)                                      /* LINE: a rule under the tabs */
        cv_rule(4, MP_Y - 3, 232, 1);
    for (k = 0; k < MTAB_COUNT; k++) {
        int on = k == (uint32_t)((mt.pos + MT_ONE / 2) / MT_ONE);   /* (half way, the shown look moves over) */
        uint16_t bg = on ? T_ACCENT : T_SURF;
        cv_rrect(x[k], MT_Y, w[k], MT_H, -8, bg, T_BG);
        GFX_HOOK_ALIGN(x[k], MT_Y, x[k] + MT_IW, MT_Y + MT_H, AL_HV, "menu tab icon centred in its cushion");
        cv_icon_in(x[k], MT_Y, MT_IW, MT_H, 16, MTAB_ICON[k], on ? T_INK : T_MID, bg);
        if (a[k] == MT_ONE) {                          /* (settled: its name) */
            GFX_HOOK_ALIGN(0, MT_Y, 0, MT_Y + MT_H, AL_V, "menu tab name centred up/down");
            cv_text_on(x[k] + MT_NX, MT_Y + (menu_large() ? CAP_IN(M, MT_H) : CAP_IN(S, MT_H)), mt_font(), MTAB_NAME[k],
                       T_INK, T_ACCENT);
        }
    }
}
/* the header's tab dots at the right, the shown tab's a THEME pill */
static void menu_dots(void)
{
    uint32_t k, t = menu_tab();
    int32_t x = 232 - (12 + (int32_t)(MTAB_COUNT - 1u) * 8);
    for (k = 0; k < MTAB_COUNT; k++) {
        cv_rrect(x, H_HEAD / 2 - 2, k == t ? 12 : 4, 4, -2, k == t ? T_THEME : T_DIM, T_BG);
        x += (k == t ? 12 : 4) + 4;
    }
}

/* a two-valued row whose values are ON and OFF: a switch (a 26 x 14 cushion, its knob at the right when ON) */
static void menu_switch(int32_t xr, int32_t y, int32_t h, int on, int sel)
{
    int32_t x = xr - 26, ty = y + HALF_UP(h - 14);
    uint16_t under = sel ? T_THEME : T_SURF;
    uint16_t track = sel ? (on ? T_INK : ux_mix(T_THEME, T_INK, 35)) : on ? T_THEME : T_DIM;
    uint16_t knob = sel ? (on ? T_THEME : T_INK) : on ? T_INK : T_TEXT;
    cv_rrect(x, ty, 26, 14, -7, track, under);
    cv_rrect(on ? x + 14 : x + 2, ty + 2, 10, 10, -5, knob, track);
}
/* the tab's row k (menu_items.c row `row`) */
static void menu_row(uint32_t k, uint32_t row)
{
    int32_t y = mr_y(k), h = mr_h(), vy = y + CAP_IN(M, h);   /* the label and its value: M (a list's rows) */
    int sel = row == ui.menu_sel;
    uint16_t bg = sel ? T_THEME : T_SURF, fg = sel ? T_INK : T_TEXT, val = sel ? T_INK : T_THEME;
    const char *v = menu_valued(row) ? menu_vname(row, menu_get(row)) : "";
    if (sel)
        cv_rrect(MR_X, y, MR_W, h, 6, T_THEME, T_SURF);
    else if (k && row - 1u != ui.menu_sel)             /* a rule from the row above (none beside the selected one) */
        cv_rect(MR_X + 6, y - 1, MR_W - 12, 1, ux.style ? T_RULE : T_LINE);
    GFX_HOOK_ALIGN(0, y, 0, y + h, AL_V, "menu row name centred up/down");
    cv_text_on(MR_LX, vy, &AF_M, MI_NAME[row], fg, bg);
    if (row == MI_LCLEAR) {                            /* LEARN CLEAR (1.5): how many CCs are learned, "NONE" */
        char b[8] = "NONE";
        if (ml_count()) {
            fmt_int(b, (int32_t)ml_count());
            str_cpy(b + str_len(b), " CC", 4);
        }
        GFX_HOOK_ALIGN(0, y, 0, y + h, AL_V, "menu row value centred up/down");
        cv_text_r(MR_VR, vy, &AF_M, b, val, bg);
        return;
    }
    if (!menu_valued(row)) {                            /* CALIBRATION, ABOUT: OCT+ opens them */
        GFX_HOOK_ALIGN(0, y, 0, y + h, AL_V, "menu row chevron centred up/down");
        cv_icon_in(MR_VR - 12, y, 0, h, 12, ICON_X_RIGHT, sel ? T_INK : T_MID, bg);
        return;
    }
    if (row == MI_HOLD || row == MI_TUNE) {            /* "0.4" s, "+12" ct: the value and its unit */
        char b[8] = "0.4";
        b[2] = (char)('0' + HOLD_MS[settings_hold % 4u] / 100u);
        GFX_HOOK_ALIGN(0, y, 0, y + h, AL_V, "menu row value centred up/down");
        GFX_HOOK_ALIGN(0, 0, 0, vy + AF_M.asc, AL_B, "menu row unit on its value's baseline");
        cv_text_r(cv_text_r(MR_VR, vy + AF_M.asc - AF_S.asc, &AF_S, row == MI_TUNE ? "ct" : "s", sel ? T_INK : T_MID, bg) - 3,
                  vy, &AF_M, row == MI_TUNE ? v : b, val, bg);
        return;
    }
    if (menu_n(row) == 2u && (str_eq(v, "ON") || str_eq(v, "OFF"))) {
        menu_switch(MR_VR, y, h, str_eq(v, "ON"), sel);
        return;
    }
    GFX_HOOK_ALIGN(0, y, 0, y + h, AL_V, "menu row value centred up/down");
    if (row != MI_COLOR) {
        cv_text_r(MR_VR, vy, &AF_M, v, val, bg);
        return;
    }
    {   /* COLOR: the palette's name and its five colours (BG SURF TEXT THEME ACCENT), live */
        uint32_t c;
        const uint16_t *tok = &T_BG;
        int32_t x0 = MR_VR - 74, sy = y + HALF_UP(h - 12);
        cv_text_r(x0 - 6, vy, &AF_M, v, val, bg);
        for (c = 0; c < 5u; c++) {
            cv_rrect(x0 + (int32_t)c * 15, sy, 12, 12, -3, T_RAISE, bg);       /* a rim for the dark ones */
            cv_rrect(x0 + 1 + (int32_t)c * 15, sy + 1, 10, 10, -2, tok[c], T_RAISE);
        }
    }
}
/* MENU > SYSTEM > INFO (1.2, ui.menu 3): what the old GLO > SYSTEM page showed, read only: the firmware, the USB link (the
 * SYSTEM page's MIDI card: OFF no USB, WAIT no bus yet, BUS frames seen, ENUM being set up, MIDI in use) and the CPU load
 * of the audio (its SYSTEM card; the shown value follows every INFO_CPU_MS, not every frame). The rows as the menu's (no
 * tabs: from INFO_Y), the selected look on none; OCT- back to the tabs, HOME closes */
#define INFO_Y 32
#define INFO_N 3u
#define INFO_CPU_MS 500u
static struct { uint8_t cpu; uint32_t t; } info;
static uint32_t info_usb(void)                         /* 0 OFF, 1 WAIT, 2 BUS, 3 ENUM, 4 MIDI */
{
    return !usb.up ? 0u : usb.config ? 4u : usb.setups ? 3u : usb.sof_seen ? 2u : 1u;
}
static uint32_t info_sig(void)
{
    if (fm1_ms - info.t >= INFO_CPU_MS) {
        info.t = fm1_ms;
        info.cpu = (uint8_t)(song.cpu_q8 * 100u / 256u);
    }
    return info.cpu * 7u + info_usb() * 131u + 1u;
}
static void info_rows(void)                            /* (in screen rows: cv_oy set by the caller) */
{
    static const char *const LBL[INFO_N] = {"FIRMWARE", "USB", "CPU"};
    static const char *const USB_N[5] = {"OFF", "WAIT", "BUS", "ENUM", "MIDI"};
    int32_t h = menu_large() ? 28 : 24;
    uint32_t k;
    char cpu[8];
    fmt_int(cpu, info.cpu);
    if (!ux.style)                                     /* FLAT: the rows' panel */
        cv_rrect(4, INFO_Y, 232, (int32_t)INFO_N * (h + 2) - 2 + 2 * MP_PAD, 8, T_SURF, T_BG);
    for (k = 0; k < INFO_N; k++) {
        int32_t y = INFO_Y + MP_PAD + (int32_t)k * (h + 2), vy = y + CAP_IN(M, h);
        if (k)
            cv_rect(MR_X + 6, y - 1, MR_W - 12, 1, ux.style ? T_RULE : T_LINE);
        GFX_HOOK_ALIGN(0, y, 0, y + h, AL_V, "info row name centred up/down");
        cv_text_on(MR_LX, vy, &AF_M, LBL[k], T_TEXT, T_SURF);
        GFX_HOOK_ALIGN(0, y, 0, y + h, AL_V, "info row value centred up/down");
        if (k == 2u) {                                 /* CPU: the value and its unit, as HOLD's */
            GFX_HOOK_ALIGN(0, 0, 0, vy + AF_M.asc, AL_B, "info row unit on its value's baseline");
            cv_text_r(cv_text_r(MR_VR, vy + AF_M.asc - AF_S.asc, &AF_S, "%", T_MID, T_SURF) - 3, vy, &AF_M, cpu, T_THEME, T_SURF);
        } else {
            cv_text_r(MR_VR, vy, &AF_M, k ? USB_N[info_usb()] : FELUCCA_VERSION, T_THEME, T_SURF);
        }
    }
}

/* the rows' two bands meet at `split`: in the gap above a row (or below the last), each band at most 124 rows */
static uint32_t menu_split(uint32_t n)
{
    int32_t s = mr_y(n) - 1;
    uint32_t k = n;
    while (s > H_HEAD + 124 && k > 1u)
        s = mr_y(--k) - 1;
    return (uint32_t)(s < 240 - 124 ? 240 - 124 : s);
}
static void draw_menu(void)
{
    static const khint_t KEYS[3][3] = {{{KC_ALGO, "TAB"}, {KC_PRESETS, "ROW"}, {KC_OCTPM, "VALUE"}},
                                       {{KC_ALGO, "TAB"}, {KC_PRESETS, "ROW"}, {KC_OCTUP, "OPEN"}},
                                       {{KC_ALGO, "TAB"}, {KC_PRESETS, "ROW"}, {KC_OCTUP, "CLEAR"}}};
    uint32_t pass, k, first, n, split, sig;
    int32_t pos0 = mt.pos;
    if (ui.menu == 1)
        mt_follow();
    sig = ui.menu * 7u + ui.menu_sel * 131u + settings.palette * 1009u + settings.lowcut * 7919u + settings_hold * 3511u +
          settings_leds * 6151u + ui_prefs * 4099u + ui_style * 257u + song.rec * 65537u + song.sel * 13u +
          ui_rec_prefs * 92821u + ui_scr * 131071u +          /* (#157: SCREEN OFF's value redraws its row) */
          ui_prefs2 * 524287u + ui_idle * 1048573u +      /* (1.2: ANIM IDLE's value redraws its row) */
          ui_home_view * 7340033u + ui_auto_evolve * 1000003u +    /* (1.3: HOME) */
          (uint32_t)(song.g[G_TUNE] + 64) * 8191u + (uint32_t)song.g[G_ROUTE] * 27449u +   /* (1.2: the project's rows) */
          (ui.menu == 2 ? ui.menu_scroll * 48611u : 0u) + (ui.menu == 3 ? info_sig() * 2654435761u : 0u);
    if (!ui.force && sig == ui.menu_sig) {
        if (ui.menu == 1 && mt.pos != pos0) {          /* only the tabs slid: their strip */
            cv_begin(240, MP_Y - H_HEAD, T_BG);
            cv_oy = -H_HEAD;
            menu_tabs();
            cv_oy = 0;
            cv_blit(0, H_HEAD);
        }
        return;
    }
    ui.menu_sig = sig;
    menu_head();
    if (ui.menu == 3) {                                /* INFO: its rows in the first band, the second clear */
        for (pass = 0; pass < 2u; pass++) {
            uint32_t top_y = pass ? 132u : (uint32_t)H_HEAD;
            cv_begin(240, pass ? 240u - 132u : 132u - H_HEAD, T_BG);
            cv_oy = -(int32_t)top_y;
            if (!pass)
                info_rows();
            cv_oy = 0;
            cv_blit(0, top_y);
        }
        return;
    }
    if (ui.menu == 2) {
        int32_t scroll = ui.menu_scroll, max = menu_scroll_max();
        int32_t thumb = MENU_DOC_H * MENU_DOC_H / (max + MENU_DOC_H);
        if (thumb < 12) thumb = 12;
        for (pass = 0; pass < 2u; pass++) {
            cv_begin(240, pass ? MENU_DOC_H - 124u : 124u, T_BG);
            cv_oy = pass ? -124 : 0;
            cv_scroll = 1;
            menu_document(-scroll, 1);
            cv_scroll = 0;
            cv_rrect(235, 2, 3, MENU_DOC_H - 4, 1, T_LINE, T_BG);           /* the scroll bar */
            cv_rrect(235, 2 + (max ? scroll * (MENU_DOC_H - 4 - thumb) / max : 0), 3, thumb, 1, T_MID, T_LINE);
            cv_oy = 0;
            cv_blit(0, H_HEAD + pass * 124u);
        }
        cv_begin(240, 240 - (H_HEAD + MENU_DOC_H), T_BG);
        cv_key_hint(8, 4, KC_PRESETS, "SCROLL", 1, T_BG);
        cv_blit(0, H_HEAD + MENU_DOC_H);
        return;
    }
    first = mtab_first(menu_tab());
    n = mtab_rows(menu_tab());
    split = menu_split(n);
    for (pass = 0; pass < 2u; pass++) {
        int32_t top_y = pass ? (int32_t)split : H_HEAD;
        cv_begin(240, pass ? 240u - split : split - H_HEAD, T_BG);
        cv_oy = -top_y;                               /* drawn in screen rows */
        if (!pass)
            menu_tabs();
        if (!ux.style)                                /* FLAT: the rows' panel */
            cv_rrect(4, MP_Y, 232, mr_y(n) - mr_gap() + MP_PAD - MP_Y, 8, T_SURF, T_BG);
        for (k = 0; k < n; k++)
            if (mr_y(k) + mr_h() > top_y && mr_y(k) - 1 < top_y + (int32_t)cv_h)
                menu_row(k, first + k);
        if (pass)
            cv_key_row(8, 232, MK_Y, KEYS[ui.menu_sel == MI_LCLEAR ? 2 : !menu_valued(ui.menu_sel)], 3, 7u, T_BG);
        cv_oy = 0;
        cv_blit(0, (uint32_t)top_y);
    }
}
static void enc_drop(void)                             /* knob turns nobody takes */
{
    uint32_t k;
    for (k = 0; k < NE; k++)
        panel_enc(k);
}

static void menu_close(void)
{
    settings_save();                                   /* palette / panel table, if changed */
    ui.menu = 0;
    ui.force = 1;
    go_home();
}

/* menu: ALGORITHM steps between the tabs, PRESETS between the rows of one (both wrap; a tab comes back at the row
 * last picked in it), any of KNOB 1..4 or OCT+ / OCT- change a value (menu_items.c menu_step), OCT+ opens CALIBRATION /
 * INFO / ABOUT (OCT- nothing there); OCT- in INFO and ABOUT goes back to the tabs. HOME closes it, from them too
 * (ui_input.c) */
static void menu_move(int32_t s)                       /* PRESETS: the next / previous row of the tab */
{
    uint32_t t = menu_tab(), f = mtab_first(t), n = mtab_rows(t), k = (ui.menu_sel - f + (s > 0 ? 1u : n - 1u)) % n;
    ui.menu_sel = (uint8_t)(f + k);
    ui.menu_row[t] = (uint8_t)k;
}
static void menu_tab_go(int32_t s)                     /* ALGORITHM: the next / previous tab, at its last row */
{
    uint32_t t = menu_tab(), k;
    ui.menu_row[t] = (uint8_t)(ui.menu_sel - mtab_first(t));
    t = (t + (s > 0 ? 1u : MTAB_COUNT - 1u)) % MTAB_COUNT;
    k = ui.menu_row[t] < mtab_rows(t) ? ui.menu_row[t] : 0u;
    ui.menu_sel = (uint8_t)(mtab_first(t) + k);
}
static void menu_input(uint32_t oct)                  /* oct: ui_input.c oct_taps */
{
    int32_t s;
    uint32_t k, up = (oct >> 1) & 1u, dn = oct & 1u;
    if (ui.menu >= 2) {                                /* ABOUT: PRESETS scrolls (bounded); INFO, ABOUT: OCT- back to
                                                        * the tabs */
        if (dn)
            ui.menu = 1, ui.force = 1;
        else if (ui.menu == 2 && (s = panel_enc(EN_PRESET)) != 0)
            ui.menu_scroll = (uint16_t)clamp((int32_t)ui.menu_scroll + clamp(s, -128, 128) * 18, 0, menu_scroll_max());
        enc_drop();
        return;
    }
    if ((s = panel_enc(EN_PRESET)) != 0)
        menu_move(s);
    if ((s = panel_enc(EN_ALGO)) != 0)
        menu_tab_go(s);
    for (s = 0, k = 0; k < 4u; k++)                    /* KNOB 1..4, any of them */
        s += panel_enc(EN_K1 + k);
    if (menu_valued(ui.menu_sel)) {
        /* a step (OCT+ the next value, OCT- the previous); COLOR previews the palette, STYLE is drawn so from the next
         * frame (FX LATCH: the latched effects are off while the menu is up) */
        s += (int32_t)up - (int32_t)dn;
        if (s)
            menu_put(ui.menu_sel, menu_step(ui.menu_sel, s));
    } else if (up) {
        if (ui.menu_sel == MI_LCLEAR) {                 /* LEARN CLEAR (1.5): every learned CC; no dialog (the menu has
                                                         * none: every other row's change is undone the same way) */
            ui_message(ml_clear_all() ? "LEARN CLEARED" : "NOTHING LEARNED");
        } else if (ui.menu_sel == MI_PANEL) {
            panel_setup();
            scrn.idle = fm1_ms;                         /* (SCREEN OFF: its own loop had the input) */
            ui.force = 1;
        } else if (ui.menu_sel == MI_INFO) {
            ui.menu = 3;
            info.t = fm1_ms - INFO_CPU_MS;              /* (the CPU load read at once) */
            ui.force = 1;
        } else if (ui.menu_sel == MI_FACTORY_RESET) {
            ui.menu = 0; ui.confirm = CF_FACTORY_RESET; ui.force = 1;
        } else {                                       /* MI_ABOUT */
            ui.menu = 2;
            ui.menu_scroll = 0;
            ui.force = 1;
        }
    }
    enc_drop();                                        /* swallow the rest while the menu is up */
}
