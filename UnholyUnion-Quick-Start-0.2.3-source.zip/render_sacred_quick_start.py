# SPDX-License-Identifier: GPL-3.0-only
"""Render the pocket hymnbook and its web edition from the adjacent guide source."""
from pathlib import Path
import json,math,html,argparse
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import Paragraph
from reportlab.graphics.barcode import qr
from reportlab.graphics.shapes import Drawing
from reportlab.graphics import renderPDF
T=Path(__file__).resolve().parent
URL='https://actuallysparky.github.io/FM-1-Unholy-Union-generative-drone-firmware/'
G='#d3ad57';INK='#191917';RED='#872d38';SILVER='#c9c8bf';PAPER='#f7f1e5'
W,H=595.276,841.89
pages=json.loads((T/'unholyunion-quick-start-0.2.3.json').read_text())
styles={k:ParagraphStyle(k,fontName='Helvetica-Bold' if k=='head' else 'Helvetica',fontSize=size,leading=leading,textColor=HexColor(color)) for k,size,leading,color in [('head',12,16,RED),('body',10.3,14,INK),('aside',9.2,12,INK)]}
def para(c,text,x,y,w,style):
 p=Paragraph(text,styles[style]);pw,ph=p.wrap(w,1000);p.drawOn(c,x,y-ph);return y-ph

def cross(c,x,y,s):
 c.setStrokeColor(HexColor(G));c.setLineWidth(1)
 for radius in (s*.55,s*.68):c.circle(x,y,radius,stroke=1,fill=0)
 for a in range(0,360,30):
  t=math.radians(a);c.line(x+math.cos(t)*s*.72,y+math.sin(t)*s*.72,x+math.cos(t)*s*.84,y+math.sin(t)*s*.84)
 c.setFillColor(HexColor(G));c.rect(x-s*.085,y-s*.49,s*.17,s*.98,stroke=0,fill=1);c.rect(x-s*.33,y+s*.07,s*.66,s*.17,stroke=0,fill=1)
 c.setFillColor(HexColor(RED));c.circle(x,y+s*.15,s*.05,stroke=0,fill=1)
def key(c,x,y,w,label):
 c.setFillColor(HexColor('#282823'));c.setStrokeColor(HexColor(G));c.roundRect(x,y,w,34,5,stroke=1,fill=1);c.setFillColor(HexColor(G));c.setFont('Helvetica-Bold',10);c.drawCentredString(x+w/2,y+12,label)
def graphic(c,kind):
 if kind=='cross':
  cross(c,455,666,95)
  c.setStrokeColor(HexColor(G));c.setLineWidth(.8)
  for i in range(85):
   x=385+i*1.7;v=9+math.sin(i*.42)*7;c.line(x,555-v,x,555+v)
 elif kind=='knobs':
  labels=[('KEY','Root / AUTO'),('SCALE','Four scales'),('RITE','Vigil / Halo / Requiem'),('STIR','Space / activity')]
  for i,(a,b) in enumerate(labels):
   x=103+i*130;c.setStrokeColor(HexColor(G));c.setFillColor(HexColor('#282823'));c.circle(x,565,17,stroke=1,fill=1);c.setLineWidth(2);c.line(x,565,x+9,578);c.setFillColor(HexColor(G));c.setFont('Helvetica-Bold',10);c.drawCentredString(x,532,'K'+str(i+1)+' / '+a);c.setFont('Helvetica',7.8);c.setFillColor(HexColor(SILVER));c.drawCentredString(x,518,b)
 elif kind=='gestures':
  for x,l in [(44,'ENV'),(176,'LFO'),(308,'OCT+')]:key(c,x,542,113,l)
  c.setFillColor(HexColor(SILVER));c.setFont('Helvetica',9);c.drawString(46,520,'Hold one modifier, then press OCT+. Keep the music flowing.')
  cross(c,506,561,40)
 elif kind=='save':
  key(c,44,542,118,'HOLD SAVE');c.setFont('Helvetica-Bold',10);c.setFillColor(HexColor(G));c.drawString(180,564,'SAVING SESSION');c.drawString(385,564,'SESSION SAVED');c.setStrokeColor(HexColor(G));c.line(180,548,505,548);c.setFont('Helvetica',9);c.setFillColor(HexColor(SILVER));c.drawString(180,530,'Wait for completion. Then let the blessing linger.')
def render(out):
 c=canvas.Canvas(str(out),pagesize=(W,H));c.setTitle('UnholyUnion - The Pocket Hymnbook - 0.2.3');c.setAuthor('UnholyUnion; upstream credits within')
 for i,page in enumerate(pages):
  c.setFillColor(HexColor(PAPER));c.rect(0,0,W,H,stroke=0,fill=1);c.setFillColor(HexColor(INK));c.rect(0,500,W,H-500,stroke=0,fill=1)
  c.setFillColor(HexColor(RED));c.rect(0,500,W,7,stroke=0,fill=1);c.setFillColor(HexColor(G));c.setFont('Helvetica-Bold',9);c.drawString(44,795,page['eyebrow'])
  c.setFont('Times-Bold',39)
  for n,line in enumerate(page['title'].split('\n')):c.drawString(44,740-n*43,line)
  subtitle=Paragraph(page['subtitle'],ParagraphStyle('sub',fontName='Helvetica',fontSize=11,leading=16,textColor=HexColor(SILVER)))
  sw,sh=subtitle.wrap(290 if i==0 else 485,90);subtitle.drawOn(c,44,638-sh)
  graphic(c,page['graphic']);y=475
  for heading,body in page['sections']:
   y=para(c,heading,44,y,507,'head')-4;y=para(c,body,44,y,507,'body')-12
  if i==0:
   c.setFillColor(HexColor(RED));c.setFont('Times-Italic',25);c.drawString(44,146,'Dearly beloved. Dearly detuned.')
  if y<155:raise ValueError(f'Page {i+1} body reaches footer: {y}')
  c.setStrokeColor(HexColor(G));c.setLineWidth(.7);c.line(44,133,551,133)
  para(c,page['aside'],44,121,424 if i==3 else 507,'aside')
  if i==3:
   q=qr.QrCodeWidget(URL);b=q.getBounds();sz=62;drawing=Drawing(sz,sz,transform=[sz/(b[2]-b[0]),0,0,sz/(b[3]-b[1]),0,0]);drawing.add(q);renderPDF.draw(drawing,c,489,61)
  c.setFont('Helvetica-Bold',8);c.setFillColor(HexColor(RED));c.drawString(44,43,'UNHOLYUNION / THE POCKET HYMNBOOK');c.drawRightString(551,43,f'{i+1} / 4')
  c.setFont('Helvetica',7);c.setFillColor(HexColor(INK));c.drawString(44,29,'0.2.3 EXPERIMENTAL / '+('Scan to enter the Ritual Room' if i==3 else 'Sacred sounds. Questionable miracles.'))
  c.linkURL(URL,(44,20,530,45),relative=0,thickness=0);c.showPage()
 c.save()
def web(out):
 blocks=[]
 for i,p in enumerate(pages):
  sections=''.join('<h3>'+html.escape(h)+'</h3><p>'+b+'</p>' for h,b in p['sections'])
  graphic='<svg viewBox="0 0 120 150" aria-hidden="true"><circle cx="60" cy="70" r="46" fill="none" stroke="currentColor"/><path d="M52 15h16v38h27v16H68v66H52V69H25V53h27z" fill="currentColor"/></svg>'
  if p['graphic']=='knobs':graphic='<div class="keys">'+''.join('<span>'+s+'</span>' for s in ('K1 KEY','K2 SCALE','K3 RITE','K4 STIR'))+'</div><p class="fine">VIGIL: warm pads / HALO: glass and shimmer / REQUIEM: darker voices</p>'
  elif p['graphic']=='gestures':graphic='<div class="keys"><span>ENV + OCT+</span><span>LFO + OCT+</span></div>'
  elif p['graphic']=='save':graphic='<div class="keys"><span>HOLD SAVE</span><span>SESSION SAVED</span></div>'
  blocks.append('<section><header><p class="eyebrow">'+p['eyebrow']+'</p><h2>'+p['title'].replace('\n','<br>')+'</h2><p>'+p['subtitle']+'</p>'+graphic+'</header><div class="body">'+sections+'<p class="aside">'+p['aside']+'</p></div></section>')
 css='''*{box-sizing:border-box}body{margin:0;background:#191917;color:#f7f1e5;font:17px/1.65 system-ui,sans-serif}main,nav,footer{max-width:1050px;margin:auto;padding:25px}nav a,footer a{color:#d3ad57}nav{display:flex;gap:24px;flex-wrap:wrap}section{margin:0 0 32px;border:1px solid #78633c;display:grid;grid-template-columns:42% 58%}header{position:relative;background:#21211c;padding:32px}h2{font:clamp(36px,5vw,57px)/1.06 Georgia,serif;color:#d3ad57;margin:20px 0}header p{color:#c9c8bf}.eyebrow{font-size:11px;letter-spacing:2px;color:#d3ad57!important}.body{padding:28px 34px;background:#f7f1e5;color:#191917;border-top:5px solid #872d38}h3{font-size:18px;color:#872d38;line-height:1.35;margin:20px 0 8px}.body p{font-size:16px;margin:0 0 14px}.aside{border-top:1px solid #c0a05b;padding-top:18px;font-style:italic}svg{width:140px;display:block;margin:30px auto;color:#d3ad57}.keys{display:flex;gap:9px;flex-wrap:wrap;margin:25px 0}.keys span{border:1px solid #d3ad57;border-radius:5px;color:#d3ad57;font-size:13px;padding:12px}.fine{font-size:12px}@media(max-width:760px){section{display:block}header{padding:26px}.body{padding:20px 26px}}'''
 out.write_text('<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>UnholyUnion - The Pocket Hymnbook</title><style>'+css+'</style><nav><a href="index.html">The Ritual Room</a><a href="UnholyUnion-Quick-Start-0.2.3.pdf" download>Download the illustrated quick start (PDF)</a><a href="UnholyUnion-User-Manual-0.2.3.pdf">The full hymnbook</a></nav><main>'+''.join(blocks)+'</main><footer><a href="'+URL+'">Enter the Ritual Room</a><p>GPL-3.0-only. Built on <a href="https://github.com/hugelton/Felucca">Felucca</a> and <a href="https://github.com/zednaked/jangada">Jangada</a>, with inspiration from <a href="https://www.cymaforma.com/rnd-synth">Cyma Forma RND</a>.</p></footer></html>')
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('--html-output',type=Path);args=a.parse_args();render(T/'UnholyUnion-Quick-Start-0.2.3.pdf')
 if args.html_output:web(args.html_output)
