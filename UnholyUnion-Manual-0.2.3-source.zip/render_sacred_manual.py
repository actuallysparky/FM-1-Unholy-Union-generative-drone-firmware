# SPDX-License-Identifier: GPL-3.0-only
from pathlib import Path
import sys,re,html,json
T=Path(__file__).resolve().parent
sys.path.insert(0,str(T.parent/'python-deps'))
from reportlab.pdfgen import canvas
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from reportlab.platypus import BaseDocTemplate,PageTemplate,Frame,Paragraph,Spacer,PageBreak,Table,TableStyle,Image,KeepTogether
from reportlab.platypus.tableofcontents import TableOfContents
from reportlab.graphics.shapes import Drawing,Rect,Line,String,Circle,Polygon
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
R=T
pdfmetrics.registerFontFamily('UU',normal='Helvetica',bold='Helvetica-Bold',italic='Helvetica-Oblique',boldItalic='Helvetica-BoldOblique')
W,H=595.276,841.89;M=45;CW=W-2*M
INK=colors.HexColor('#29261f');TEAL=colors.HexColor('#885721');GOLD=colors.HexColor('#936720');PALE=colors.HexColor('#f8f3e8');GREY=colors.HexColor('#746955')
S={
 'body':ParagraphStyle('body',fontName='Helvetica',fontSize=10.2,leading=14.1,textColor=INK,spaceAfter=8),
 'source':ParagraphStyle('source',fontName='Helvetica',fontSize=8.2,leading=11,textColor=GREY,spaceAfter=5),
 'h1':ParagraphStyle('h1',fontName='Helvetica-Bold',fontSize=34,leading=37,textColor=TEAL,spaceBefore=32,spaceAfter=20),
 'h2':ParagraphStyle('h2',fontName='Helvetica-Bold',fontSize=21,leading=25,textColor=TEAL,spaceAfter=14,keepWithNext=True),
 'h3':ParagraphStyle('h3',fontName='Helvetica-Bold',fontSize=13,leading=17,textColor=TEAL,spaceBefore=10,spaceAfter=7,keepWithNext=True),
 'cell':ParagraphStyle('cell',fontName='Helvetica',fontSize=8.7,leading=11.7,textColor=INK,spaceAfter=0),
 'head':ParagraphStyle('head',fontName='Helvetica-Bold',fontSize=8.7,leading=11.7,textColor=colors.white,spaceAfter=0),
 'list':ParagraphStyle('list',fontName='Helvetica',fontSize=10.2,leading=14.1,leftIndent=17,firstLineIndent=-17,textColor=INK,spaceAfter=7),
}
def norm(x):
 replacements={'→':' -> ','×':'x','−':'-','–':'-','—':'-','±':'+/-','⁄':'/','…':'...','€':'EUR ','’':"'",'‘':"'",'“':'"','”':'"','🛶':'','↗':''}
 for a,b in replacements.items():x=x.replace(a,b)
 # join-code values occasionally intentionally compact, otherwise preserve words.
 return x

def fmt(x):
 x=html.escape(norm(x))
 x=re.sub(r'\[([^]]+)\]\((https?://[^)]+)\)',lambda m:f'<link href="{m[2]}" color="#885721"><u>{m[1]}</u></link>',x)
 x=re.sub(r'\*\*(.*?)\*\*',r'<b>\1</b>',x)
 x=re.sub(r'`(.*?)`',r'<font name="Helvetica">\1</font>',x)
 return x
class D(BaseDocTemplate):
 def __init__(self,out):
  super().__init__(str(out),pagesize=(W,H),leftMargin=M,rightMargin=M,topMargin=48,bottomMargin=47,title='UnholyUnion - The Book of Sacred Sounds - 0.2.3',author='UnholyUnion project; upstream attribution within',subject="Immaculate Permutation and a musician's guide to UnholyUnion",pageCompression=1)
  self.addPageTemplates(PageTemplate(id='main',frames=Frame(M,47,CW,H-95,leftPadding=0,rightPadding=0,topPadding=0,bottomPadding=0),onPage=self.decorate));self.book=[];self.chapter=''
 def decorate(self,c,doc):
  c.saveState();c.setStrokeColor(colors.HexColor('#d1bb86'));c.line(M,H-32,W-M,H-32);c.setFont('Helvetica',8);c.setFillColor(GREY);c.drawString(M,H-25,'UNHOLYUNION / THE BOOK OF SACRED SOUNDS');c.drawRightString(W-M,H-25,'IMMACULATE PERMUTATION / 0.2.3');c.line(M,34,W-M,34);
  if doc.page==1:
   c.setFillColor(colors.HexColor('#bd9543'));c.roundRect(W/2-9,170,18,174,4,stroke=0,fill=1);c.roundRect(W/2-56,279,112,18,4,stroke=0,fill=1);c.setStrokeColor(colors.HexColor('#e9dfc6'));c.circle(W/2,257,116,stroke=1,fill=0);c.setFont('Helvetica-Bold',12);c.drawCentredString(W/2,125,'FOR RICHER HARMONICS. FOR POORER SLEEP.');
  c.drawString(M,21,'Go in peace. Leave the reverb tail.');c.drawRightString(W-M,21,str(doc.page));c.restoreState()
 def afterFlowable(self,f):
  if isinstance(f,Paragraph) and hasattr(f,'tocTitle'):
   key=f.key;self.canv.bookmarkPage(key);self.canv.addOutlineEntry(f.tocTitle,key,0,False);self.notify('TOCEntry',(0,f.tocTitle,self.page,key));self.book.append((f.tocTitle,self.page,key))

def box(d,x,y,w,h,label,fill=PALE,size=10):
 d.add(Rect(x,y,w,h,rx=5,ry=5,fillColor=fill,strokeColor=TEAL,strokeWidth=.8));d.add(String(x+8,y+h/2-3,label,fontName='Helvetica',fontSize=size,fillColor=INK))
def diagram(kind):
 if kind=='panel':
  d=Drawing(CW,178);d.add(Rect(1,1,CW-2,174,rx=13,ry=13,fillColor=PALE,strokeColor=TEAL))
  for x,y,l in [(33,135,'MASTER'),(104,135,'SELECT'),(33,91,'PRESETS'),(104,91,'ALGORITHM')]:
   d.add(Circle(x,y,12,fillColor=colors.white,strokeColor=TEAL));d.add(String(x,y-24,l,fontName='Helvetica-Bold',fontSize=7.7,textAnchor='middle',fillColor=INK))
  d.add(Rect(148,74,117,77,fillColor=TEAL,strokeColor=TEAL));d.add(String(206,118,'1  /  SCREEN',fontName='Helvetica-Bold',fontSize=12,textAnchor='middle',fillColor=colors.white));d.add(String(206,95,'track in header',fontName='Helvetica',fontSize=9,textAnchor='middle',fillColor=colors.white))
  for n in range(4):
   x=303+n*51;d.add(Circle(x,141,10,fillColor=colors.white,strokeColor=TEAL));d.add(String(x,122,'K'+str(n+1),fontName='Helvetica-Bold',fontSize=9,textAnchor='middle',fillColor=INK))
  for n,l in enumerate(['FX','SCL','ENV','LFO','EDIT','GLO','HOME','SAVE','ARP','SEQ','PLAY','REC']):
   x=275+n%6*36;y=88-n//6*29;d.add(Rect(x,y,33,24,fillColor=colors.white,strokeColor=TEAL));d.add(String(x+16,y+8,l,fontName='Helvetica-Bold',fontSize=7,textAnchor='middle',fillColor=INK))
  d.add(String(36,28,'OCT- / OCT+       F3-G5 keyboard: selected track',fontName='Helvetica',fontSize=10,fillColor=INK));return d
 if kind=='tracks':
  d=Drawing(CW,122)
  for n in range(4):box(d,n*125,63,115,47,f'T{n+1} engine + notes',size=9);d.add(Line(n*125+57,63,n*125+57,46,strokeColor=TEAL))
  box(d,85,4,330,40,'Shared budget: 8 sounding voices',size=12);return d
 if kind=='mod':
  d=Drawing(CW,90);box(d,0,27,128,45,'SRC: DRIFT / MAC1');box(d,181,27,124,45,'Signed AMT');box(d,357,27,147,45,'DST: tone / pan / FX');d.add(Line(128,50,181,50,strokeColor=TEAL));d.add(Line(305,50,357,50,strokeColor=TEAL));d.add(String(1,8,'Four independent routes on each track; MAC values shared across tracks.',fontName='Helvetica',fontSize=9,fillColor=GREY));return d
 if kind=='audio':
  d=Drawing(CW,130)
  labs=['Engine voices','DIST / INSERT','SLICER','Level / pan / sends','Shared FX / mix','MASTER / limiter','Analog + USB capture']
  for n,l in enumerate(labs):
   x=0 if n<4 else 265;y=94-(n if n<4 else n-4)*27;box(d,x,y,235,22,l,size=9)
   if n not in[3,6]:d.add(Line(x+117,y,x+117,y-5,strokeColor=TEAL))
  d.add(Line(235,24,252,24,strokeColor=TEAL));d.add(Line(252,24,252,106,strokeColor=TEAL));d.add(Line(252,106,265,106,strokeColor=TEAL));return d

def make_story(md):
 story=[];lines=md.splitlines();i=0;key=0;toc_done=False
 while i<len(lines):
  l=lines[i].strip()
  if not l:i+=1;continue
  if l=='<!-- PAGE -->':
   story.append(PageBreak());i+=1
   continue
  if l=='<!-- CONTENTS -->':
   story.append(Paragraph('The order of service',S['h2']));toc=TableOfContents();toc.levelStyles=[ParagraphStyle('toc',fontName='Helvetica',fontSize=9.5,leading=12.8,textColor=INK,leftIndent=0,firstLineIndent=0,spaceBefore=0)];story.append(toc);i+=1;continue
  if l.startswith('<!-- DIAGRAM '):story.append(diagram(l[13:-4].strip()));story.append(Spacer(1,8));i+=1;continue
  if l=='<!-- IMAGE drone -->':
   story.append(Image(str(T/'unholy-drone-preview.png' if (T/'unholy-drone-preview.png').exists() else R/'web/unholy-drone-preview.png'),width=173,height=173,hAlign='LEFT'));story.append(Spacer(1,8));i+=1;continue
  if l.startswith('## '):
   title=norm(l[3:]);p=Paragraph(fmt(title),S['h2']);p.tocTitle=title;p.key='ch'+str(key);key+=1;story.append(p);i+=1;continue
  if l.startswith('### '):story.append(Paragraph(fmt(l[4:]),S['h3']));i+=1;continue
  if l.startswith('# '):story.append(Paragraph(fmt(l[2:]),S['h1']));story.append(Spacer(1,18));i+=1;continue
  if l.startswith('|'):
   rows=[]
   while i<len(lines) and lines[i].strip().startswith('|'):
    raw=lines[i].strip()
    if not re.match(r'^\|[\s|:-]+\|$',raw):rows.append([c.strip() for c in raw.strip('|').split('|')])
    i+=1
   nc=len(rows[0]);widths={2:[146,CW-146],3:[121,161,CW-282],4:[125,93,93,CW-311],5:[112]+[(CW-112)/4]*4}[nc]
   if rows[0][0]=='Position / label':widths=[146,CW-146]
   if rows[0][0]=='ID / label':widths=[90,285,CW-375]
   data=[[Paragraph(fmt(c),S['head' if j==0 else 'cell']) for c in row] for j,row in enumerate(rows)]
   table=Table(data,colWidths=widths,repeatRows=1,hAlign='LEFT',splitByRow=1)
   table.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),TEAL),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,PALE]),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),7),('RIGHTPADDING',(0,0),(-1,-1),7),('TOPPADDING',(0,0),(-1,-1),6),('BOTTOMPADDING',(0,0),(-1,-1),6),('LINEBELOW',(0,0),(-1,0),.6,TEAL),('LINEBELOW',(0,1),(-1,-1),.3,colors.HexColor('#e5d8bb'))]));story.append(table);story.append(Spacer(1,10));continue
  if re.match(r'^\d+\. ',l):
   story.append(Paragraph(fmt(l),S['list']));i+=1;continue
  p=[]
  while i<len(lines) and lines[i].strip() and not lines[i].strip().startswith(('#','|','<!--')) and not re.match(r'^\d+\. ',lines[i].strip()):p.append(lines[i].strip());i+=1
  joined=' '.join(p)
  st='source' if joined.startswith('Source:') else 'body'
  story.append(Paragraph(fmt(joined),S[st]))
 return story
src=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else T/'UnholyUnion-User-Manual-0.2.3.md';out=Path(sys.argv[2]).resolve() if len(sys.argv)>2 else T/'UnholyUnion-User-Manual-0.2.3.pdf'
doc=D(out);doc.multiBuild(make_story(src.read_text()));(out.with_suffix('.bookmarks.json')).write_text(json.dumps(doc.book,indent=2));print(out)
