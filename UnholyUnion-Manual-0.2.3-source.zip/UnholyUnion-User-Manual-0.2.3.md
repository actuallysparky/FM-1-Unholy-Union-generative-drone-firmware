# UnholyUnion

**The Book of Sacred Sounds**

A musician's companion for the M-VAVE FM-1

Immaculate Permutation edition | 0.2.3 | October 2026

Dearly beloved. Dearly detuned.

Welcome to a small congregation of warm drones, wandering melodies and gloriously questionable timbres. Let the notes breathe. Leave room for the reverb. When inspiration wanders off, ask for another miracle.

Brother Sparky has tried his best to craft a sermon fit for your ears. Like all things on this earth, it may be imperfect. Bring curiosity, keep your scriptures safe, and forgive the occasional questionable miracle.

<!-- PAGE -->
## 1. Immaculate Permutation: your first revelation

**One button. Four voices in fellowship. A fresh invitation to play.**

The instrument opens on IMMACULATE PERMUTATION with track 4 selected. Your restored session stays yours: opening this screen does not replace your music. On a fresh session, the curated **Evening Vow** awaits. Press **PLAY**, then play the keyboard. The accompaniment is ready; the fourth track is your pulpit.

For a new arrangement, release held keyboard and MIDI notes, then press **OCT+**. If playback was running, the music fades, changes and resumes. If stopped, press PLAY to hear the new revelation. Recording is disarmed. A full revelation replaces the current working project, so save any beloved sermon first.

| Part | Its place in the congregation |
| --- | --- |
| Track 1 | A sustained foundation: warmth beneath the stained glass. |
| Track 2 | A sparse, repeating melody with room between the notes. |
| Track 3 | A recorded chord arpeggio, ready to play without holding a chord. |
| Track 4 | A matching live sound with no sequence. Selected, unmuted and waiting for your hands. |

The panel keyboard follows the chosen scale, helping your live part sit with the accompaniment. External MIDI follows the ordinary MIDI note rules, so keep incoming notes in the same key yourself.

**OCT- or HOME** leaves this screen. Tap HOME through HOME, MIXER and CLOCK to return. To make a new world you must press OCT+; merely visiting never summons one.

<!-- PAGE -->
## 2. Choose your rite

The four knobs shape the next revelation. They do not rewrite the music until you press OCT+.

| Control | Invitation |
| --- | --- |
| K1 KEY | AUTO, or choose a root from C through B. Keep a favourite key when playing with other instruments. |
| K2 SCALE | AUTO, Minor, Dorian, Minor pentatonic or Major pentatonic. AUTO leans toward minor, with the other colours also welcome. |
| K3 RITE | VIGIL for warm pads; HALO for shimmering, glassy bells; REQUIEM for darker voice and physical tones. |
| K4 STIR | Low for spacious phrases; higher for more melody and arpeggio activity. Even a busy congregation needs breaths. |
| SELECT | Choose 40-110 BPM, or turn below 40 for AUTO. AUTO favours an unhurried 45-75 BPM. With external clock, your clock source sets the pace. |

**Try this:** Minor, VIGIL, low STIR and about 60 BPM. Reveal, press PLAY if needed, and add a few upper notes on track 4. Let a note finish before offering the next. For a lighter window of colour, try Major pentatonic with HALO.

### The Choir Master

Every full revelation now receives a little help at the mixing altar. The Choir Master considers the chosen sounds and their register, giving the drone a foundation, the melody a place to speak, the arp room to shimmer and your live track space to answer. Bright voices are encouraged to share the pulpit; soft ones receive a gentle lift.

These are starting levels, not commandments. Some presets still whisper, and your listening setup changes what reaches your ears. Visit MIXER and turn LEVEL whenever a part needs more or less presence. Evolve and the LFO blessing keep those choices intact. Evening Vow remains our curated first hymn.

All four parts share a musical key. Presets are chosen for their role, rather than turning every sound control into a lottery. Full revelation leaves the LFOs alone: ask for their blessing separately when you want it.

The prayer words change with each accepted action. Praying, sanctifying, revealing: the liturgy is varied, the button remains OCT+.

<!-- PAGE -->
## 3. Evolve the sermon; bless its movement

**Hold ENV and press OCT+ to Evolve.** The backing notes find a new in-key progression while playback continues. Your presets, sound settings, rhythm, velocities, tempo and LFOs stay with you. Track 4 remains entirely yours. Currently sounding notes keep ringing; the change arrives in upcoming notes.

Evolve works when the first three tracks share a root and one of these scales: Minor, Dorian, Minor pentatonic or Major pentatonic. If they do not, bring them into the same key and scale first. Turning the revelation's KEY control alone does not retune an existing project.

### A procession that evolves by itself

Hold HOME, choose SYSTEM, then **AUTO EVOLVE**: OFF, 2, 4, 8, 12, 16, 24 or 32 BARS. New sessions start at 16 BARS. A bar is four beats of the active clock. Saved settings stay yours; Return to Evening Vow restores 16 BARS.

While PLAY runs, the backing harmony evolves at that interval, using the same gentle changes as ENV + OCT+. Your key, sounds, rhythms, LFOs and live track stay with you. The selected track stays selected. Notes already ringing carry on; upcoming notes introduce the new harmony.

The chosen value lights up as you turn it. Evolution continues while AUTO EVOLVE itself is selected. Recording, other menu pages, shortcut maps and transfers skip an interval rather than springing a delayed miracle on you afterwards. Stopping and restarting begins a fresh wait. The same shared-key and scale rules apply as for manual Evolve.

### Octaves for the selected part

On ordinary performance pages, OCT+ and OCT- move the selected track up or down an octave: its live keyboard, latched arp and forthcoming sequence notes. Other tracks stay put. Each track remembers its own temporary shift, up to three octaves either way. Press both octave buttons to return that track to its original octave.

Already sounding notes can finish naturally. Drum kit notes keep their drum assignments. Stored pattern notes remain unchanged; loading a project, a full revelation or project undo clears these temporary shifts. On Immaculate Permutation, OCT+ still Reveals and OCT- leaves the screen. The ENV/LFO + OCT+ gestures still Evolve or bless, without an octave change.

**Hold LFO and press OCT+ for a gentle blessing on all four tracks.** Slow sine or triangle movement adds a little wandering pan, reverb or chorus. Notes, presets, key and tempo stay in place, and playback continues. Hold a live note through either gesture if you like.

The blessing replaces existing LFO assignments and uses modulation slot 4. Other non-LFO routes in slots 1-3 stay. If you use the Procession macro in slot 4, this blessing replaces that route too. Listen, then visit MOD or the editor to shape the result further. Evolve never changes your LFO blessing.

Both gestures work on ordinary performance pages as well as Immaculate Permutation. Menus, naming, confirmations, save/load actions and open shortcut maps keep their own controls; return to a performance page first. Use one held modifier at a time.

**Hold OCT− on the Immaculate Permutation screen** to undo the last revelation, evolution or LFO blessing. If you have edited the result, the first hold warns; hold again to replace those edits. Release held notes first. Undo makes a brief transition and resumes prior playback. It lasts only for the current session and disappears after a project load or reset. Elsewhere, SAVE's undo has its ordinary, more limited role.

Hold LFO and turn a sound knob to audition a temporary change; release LFO to return. LFO + OCT+ requests the blessing and first restores any temporary knob previews. Save lasting edits through the normal sound or project controls.

<!-- PAGE -->
## 4. Evening Vow: the curated first hymn

The opening eight bars preserve your saved progression. The answering eight open the voicings, lift a few notes and return to A minor. The pad enters first, the sequence after two beats, and the arp after four. These entrances are rests in the loops, so they travel with exports.

A minor. 72 BPM. Warmth below, a shimmer above, and an open space for you. A fresh congregation wears GILT SIN: gold, silver, crimson and black. Boot greets you with **Press PLAY to pray**, then gently fades away. Press PLAY at any point to begin; your saved music and chosen colors stay yours. The buttons for available rites light your way.

| Track | Evening Vow |
| --- | --- |
| 1 | ANALOG SOFT PAD: a warm, slowly evolving drone. |
| 2 | FM6 BELL: your progression, developed into a sixteen-bar chord sequence. |
| 3 | PHASE STRING: a recorded chord arpeggio. |
| 4 | PHYS BOWED METAL: a live monophonic voice, with an empty sequence. |

Press PLAY to hear the three backing tracks. Track 4 is selected so you can answer them immediately. You need not latch a chord or record anything first. Your later saved session takes precedence at startup; Evening Vow does not overwrite your work every time you power on.

### Return to Evening Vow

Hold HOME, choose SYSTEM, then FACTORY RESET. Press OCT+ to open **Return to Evening Vow?** OCT- cancels; OCT+ confirms.

This replaces the current unsaved session and returns common interface settings to their starting values. **Saved projects, user presets, favourites, samples, MIDI learn and panel calibration remain.** The instrument returns stopped to Immaculate Permutation with track 4 selected. The previous action undo is cleared.

Before powering off, leave it stopped, quiet and idle for a minute so the restored session has time to settle into autosave. Save precious work to a project slot before resetting.

### Keep a revelation

On Immaculate Permutation, **hold SAVE for a little over a second** to keep the current sermon while PLAY continues. The first empty A-D slot becomes SERMON A-D. **SAVING SESSION** stays on screen until the save finishes. **SESSION SAVED** then remains for three seconds, with the destination slot beneath it. Find your saved sermon under SAVE → PROJECT, in A–D. Wait for **SESSION SAVED** before switching off. If you see SESSION NOT SAVED, the sermon was not kept; try again before switching off. If all four slots are full, choose one with K1, then OCT+ and confirm the overwrite. Ordinary named saves remain available: stop, tap SAVE to PROJECT, choose a slot and SAVE, then OCT+ to name it.

In the editor's Projects tab, **Export scripture** keeps the complete current project on your computer. **Receive scripture** brings one back into the current session. It does not replace saved banks, samples or device settings. A seed can repeat an original recipe; export the whole project to keep your subsequent edits.

<!-- PAGE -->
## 5. The saints behind the sound

**Saint Felucca, our foundation.** Praise [Felucca](https://github.com/hugelton/Felucca), Leo Kuroshita (@kurogedelic), Hügelton Instruments and every contributor. Their engines, sequencer, modulation, effects, storage, editor and updater carry this congregation.

**Saint Jangada, patron of the note that refuses to leave.** Praise [Jangada](https://github.com/zednaked/jangada), zednaked and its contributors. Their drone work inspired and supplied the adapted evolving sustain and tension at the heart of our long devotions.

**Archangel Chance, keeper of the blessed roll.** Praise [Cyma Forma and Bambounou's RND synth](https://www.cymaforma.com/rnd-synth), whose one-button invitation helped inspire Immaculate Permutation. May their random wonders ring through every sacred valley.

UnholyUnion adapts Felucca and Jangada code. RND is design inspiration; no RND code or artwork was copied. These creators have not endorsed this independent project. We sing their praises with gratitude, not borrowed authority.

### Reading the rest of the book

K1-K4 are the four numbered parameter knobs, left to right. A button name is its printed panel label. Tap means press and release; hold means keep it down while taking the next action. Pages and control names stay literal so the hymnbook matches the instrument.

Begin with a recipe. Reach for the reference when a sound asks a deeper question. No examination follows the sermon.

<!-- PAGE -->
<!-- CONTENTS -->
<!-- PAGE -->
## 6. Connect and hear the choir

Begin quietly. A small miracle needs no loud entrance.

### Listen first, quietly

Power the FM-1 normally and wait for its firmware screen. Start with MASTER and your external listening level low. Use the built-in speaker, the analog headphone/audio output, or USB recording monitored through a computer. Headphone insertion mechanically disables the speaker; SPEAKER EQ is an EQ, not a speaker mute switch.

Choose BlessedAudio or BlessedUnion as the audio input in your recording app, then enable monitoring to hear the instrument through the computer. BlessedMIDI carries notes and controls; it does not carry the sound. USB records the FM-1 into the computer, rather than playing computer audio through the synth. 

For recording, set MENU > AUDIO > SPEAKER EQ to FLAT. USB LEVEL MASTER follows the instrument's volume; FIXED sends the full-level mix to USB even when MASTER is low. Reduce monitoring gain before changing that setting. The metronome goes to speaker/headphones, not USB recording.

### A known audible starting point

1. Tap HOME until HOME appears. Release EDIT/other held layers. Turn the ALGORITHM rotary knob (lower-right in the left four-knob cluster) to track 1. Clockwise moves toward T4; counterclockwise toward T1, stopping at the ends. Watch the number at the left of the header.
2. Hold EDIT. K1 selects ANALOG; K2 selects SOFT PAD. Release EDIT.
3. Tap ARP until ARP appears. K1 MODE OFF. Tap to DRONE: HOLD OFF, EVOL 0%, TENS 0%, RAMP OFF.
4. Play and hold a panel key. SOFT PAD attacks slowly; wait for it. Raise listening volume gradually.
5. Tap HOME until MIXER if silent. On T1 set MUTE OFF and LEVEL above its minimum. Check cable, input selection and monitoring.

Loading a factory sound leaves the track's sequence, arp/HOLD, level, mute and scale settings in place. It resets the sound and its matrix/drone parameters, but not shared macros or global effects. For an edited project, follow the reset checklist later rather than assuming a preset load resets everything.

Use the Ritual Room's hands-on guide for a compact bedside reference. This book is also happy on an iPad.

<!-- PAGE -->
## 7. Know your sacred instrument

These are the doors, candles and bells of your little chapel.

<!-- DIAGRAM panel -->

| Control | Ordinary role |
| --- | --- |
| MASTER | Listening level. USB LEVEL FIXED can bypass it for USB recording. |
| SELECT | Global tempo. With BPM LOCK, hold GLO while turning, or use CLOCK. |
| ALGORITHM | Select track T1-T4. It does not select a synthesis algorithm. |
| PRESETS | Browse sounds on HOME and most sound pages; different jobs on lists, sequence pages and dialogs. |
| K1-K4 | Edit the four visible columns. Engine HOME controls differ from EDIT parameters. |
| Function buttons | Tap for pages; eligible buttons held or double-tapped open shortcut layers. |
| OCT- / OCT+ | Selected-track octave shift for keyboard, arps and sequences; cancel/back and do/confirm in action contexts. Together reset keyboard octave in ordinary play. |
| PLAY / REC | Transport start/stop and selected-track recording arm. |
| Keyboard | Plays the selected track; in grids, layers or naming screens it has that screen's role. |

The keyboard spans F3-G5 at its base octave. Octave shift normally runs -3 to +3. A key pressed while a layer button is held is a shortcut, not a played/recorded note. Keys already held before opening a layer retain their note ownership.

**Do not infer a universal panic gesture from OCT- + OCT+.** In normal play they reset octave; their action changes in dialogs and set layers. The silence chapter explains how to release latches and stop generators.

<!-- PAGE -->
## 8. Walk the chapel: pages and shortcuts

Follow the printed labels; even saints need signposts.

| Button | Page cycle in this build |
| --- | --- |
| HOME | HOME -> MIXER -> CLOCK -> IMMACULATE PERMUTATION -> HOME. From another family it returns HOME. |
| ENV | ENV -> ENV DEST. |
| LFO | LFO -> LFO 2 -> LFO DEST -> MOD -> MACRO. |
| ARP | ARP -> ARP 2 -> DRONE. |
| EDIT | EDIT 1/2, engine-specific pages when applicable, VOICE/VOICE 2/VOICE 3. |
| FX | FX -> SLICER -> INSERT -> INSERT 2 -> DLY -> REVERB -> CHORUS. |
| SCL | SCL -> CHORD. |
| SEQ | STEP -> DETAIL -> AUTOMATION; DRUM uses a grid under STEP/DETAIL. |
| GLO | SONG. |
| SAVE | USER -> PRESETS -> PHRASES -> PROJECT -> TOOLS. |

Most families remember their last page. Returning from elsewhere may land on that page rather than the first; tap until the wanted title appears. SAVE enters USER from another family. Taps act on release. Leave more than 0.3 seconds between separate page taps when you do not want a double-tap layer lock.

**Hold FX, GLO, SCL, EDIT, SEQ or REC** to open its map. The default hold threshold is 0.4 seconds; the menu allows 0.3-0.6 seconds. Turning a knob or pressing a key while holding opens it immediately. Double-tap a layer button to leave the map open; tap it again or another page button/HOME to close it. Use the double-tap shortcut above to keep a map open.

Hold HOME about 0.7 seconds for the menu. In the menu ALGORITHM selects a tab, PRESETS selects its row, K1-K4 or OCT-/OCT+ changes the value; HOME exits. CALIBRATION, INFO and ABOUT open with OCT+.

Hold LFO and turn ordinary sound/FX knobs for momentary edits; release to restore. LFO + OCT+ applies the gentle all-track blessing described at the front of this book. Hold SAVE about 0.7 seconds for supported one-step undo; it is not a universal undo for every knob change. Set layers use OCT- to restore their opening state.

<!-- PAGE -->
## 9. Four tracks in fellowship

Give every voice a place, and leave a little air between them.

A **track** holds an engine, its sound, sequence, arp, modulation and mix settings. A **voice** is one sounding note inside an engine. Four tracks do not mean four fixed notes, and eight voices are **shared across the instrument**, not eight guaranteed on each track.

Each track can choose any selectable engine, including DRUM. T4 is an ordinary fourth part, initially the live PHYS BOWED METAL in Evening Vow, with no separate DRUM/SYNTH type switch. ALGORITHM selects the track whose keys and editing pages you control. Release physical keys before changing focus to make latch ownership easy to follow. Track selection itself does not silence a released latched drone/arp.

| Scope | Examples |
| --- | --- |
| Per track | Engine/preset, envelope, LFO, four matrix slots, arp MODE/HOLD, EVOL/TENS/RAMP, scale/chord, level/pan/mute, insert/sends, sequence and timing. |
| Shared song/project | BPM/clock, tuning, delay/reverb/chorus settings, MIDI routing, song chain, four MAC values. |
| Device preferences | Display, layer hold time, USB level/serial, metronome settings, MIDI LEARN map, RESTORE LAST. |

Engine caps are FM6 6, VOICE 4, GRAIN 3 and PHYS 3; the ordinary maximum for uncapped synths is 8, still within the shared budget. DRUM has eight lane voices but uses that same budget. UNI can spend multiple voices on one note. Long release tails count until silent.

When full, the allocator prefers old released voices, then extra unison voices, then eligible held poly voices. A dense new part can therefore steal a drone tone. Start with two or three drone notes, one arp note at a time, and a few drum hits; shorten releases or reduce unison before blaming MIDI.

<!-- DIAGRAM tracks -->

On a fresh session the four parts form Evening Vow: pad, bell melody, string arpeggio and live bell. RESTORE LAST can bring back your previous session instead.

<!-- PAGE -->
## 10. A vigil for drone and arpeggio

A patient foundation below, a small procession above.

### Set track 1's steady drone

1. Low listening volume. HOME -> CLOCK: K3 CLK INT. SELECT chooses BPM (hold GLO if BPM LOCK is on).
2. HOME; ALGORITHM -> T1. Hold EDIT: K1 ANALOG, K2 SOFT PAD; release.
3. ARP page: K1 MODE OFF. DRONE page: K1 HOLD ON, K2 EVOL about 20%, K3 TENS 0%, K4 RAMP OFF.
4. Play a small chord and release every key. The chord stays on T1.

### Set track 2's arpeggio

5. ALGORITHM -> T2. Hold EDIT: K1 ANALOG, K2 PLUCK; release.
6. ARP page: K1 UP, K2 RATE 1/8, K3 OCT 1, K4 GATE about 50%.
7. ARP 2: K2 PROB 100%, K3 HOLD ON. Play and release a chord.

T2 now arpeggiates while T1 drones. Internal-clock arps and the steady drone need no PLAY press. PLAY starts stored sequences as well, so use it intentionally. BPM is shared; arp settings and HOLD belong to their own tracks. The selected track receives the panel keys. For external input, CH1-4 maps MIDI channel 1 to T1 and channel 2 to T2; SEL instead follows editing focus.

**Balance:** HOME until MIXER. ALGORITHM selects T1/T2; K1 LEVEL, K2 PAN, K3 REV send, K4 MUTE. Try modest opposite pans and a lower arp level.

**Finish:** release keys; set HOLD OFF on both tracks, then T2 MODE OFF. Stop PLAY if it is running. Release tails can continue. Muting stops hearing a part but need not stop its internal playback.

**Keep the setup:** stop transport, SAVE until PROJECT, K1 chooses A-D, turn K4 to select SAVE, OCT+; confirm overwrite if asked, then OCT+ on the naming screen. Projects save settings, not the currently sounding chord latch. Play the chords again after loading.

<!-- PAGE -->
## 11. Keys, scales and one-finger congregations

Let the scale gather your notes into fellowship.

SCL has K1 ROOT, K2 SCL, K3 QNT, K4 TRN. ROOT runs C-B, TRN -24 to +24 semitones. The 16 scales are CHR, MAJ, MIN, DOR, MIX, PEN, MPEN, HARM, PHRY, LYD, LOC, MEL, BLUES, WHOLE, DIMHW and DIMWH. 

| QNT | Result |
| --- | --- |
| OFF | Normal chromatic panel keyboard. |
| SNAP | Panel notes round down into the selected scale. |
| WHITE | White keys walk the scale; C4 gives ROOT. Black keys are silent for notes, recording and step entry. |
| SEQ | SNAP for keys, plus scale mapping of sequenced notes at playback; stored note data stays unchanged. |

Octave buttons transpose the panel mapping; TRN then transposes the result. Incoming MIDI keeps its note mapping instead of the WHITE-key layout. Drum kits and slice key maps have their own mapping; drum hits are not scale-quantized. A scale with fewer/more than seven notes does not necessarily put every root on a C key.

SCL again opens CHORD. K1 CHRD: OFF, DIA3, DIA7, MAJ, MIN, DOM7, MAJ7, MIN7, SUS4, POW. DIA3/DIA7 derive tones from the track's scale; fixed shapes follow the root note. K2 VOIC: CLOSE, OPEN, INV1, INV2, +OCT. At most four tones are made. Chords can be played from panel keys or MIDI, recorded, or fed to the arp.

**Try:** choose ANALOG SOFT PAD in POLY, SCL ROOT C/SCL MIN/QNT WHITE, then CHORD DIA3/CLOSE. One white key gives an in-key triad. For the manual's literal three-key drone recipe, set CHRD OFF first so each key does not generate another chord.

Holding SCL changes the layer's knobs to ROOT, SCL, CHRD, VOIC; a keyboard key sets ROOT. This is not the ordinary SCL page's four columns. 

<!-- PAGE -->
## 12. Breath and motion: envelopes and LFOs

Attack is the entrance; release is the farewell. Neither needs to hurry.

ENV K1-K4 are ATK, DEC, SUS, REL. Attack/decay/release use nonlinear time controls, not raw milliseconds; SUS is a 0-100% level. Sustain must be nonzero for a normal oscillator patch to keep sounding with HOLD. Physical/sample/one-shot engines may still decay for their own reasons.

ENV DEST has K1 FLT, K2 PIT, K3 SHP (signed depths) and K4 ESYNC. ESYNC ON shows time divisions from zero and short triplet/dotted values through 4BAR, following tempo instead of fixed time. The envelope uses amplitude as well as routed modulation; FLT/SHP mean different timbral destinations in different engines.

EDIT's VOICE pages:

| Page | K1 | K2 | K3 | K4 |
| --- | --- | --- | --- | --- |
| VOICE | VCE POLY/MONO/LEG/UNI | GLD | GLMOD RATE/TIME | PRIO LAST/LOW/HIGH |
| VOICE 2 | ALLOC ROT/REUSE | DTN | PAN | MUTE |
| VOICE 3 | SPRD | - | - | - |

POLY supports chords; MONO retriggers a monophonic line; LEG is legato; UNI stacks available voices on one note. Glide RATE and TIME change the glide behavior. REUSE prefers a reusable voice; ROT rotates allocation. SPREAD alternates poly/unison voices around PAN. It is stereo width, not track duplication.

LFO K1 RATE, K2 WAVE (SIN/TRI/SAW/SQR/S&H), K3 PHS, K4 FADE. LFO 2 has K1 SYNC, K2 TRIG NOTE/FREE, K3 POL BI/UNI. SYNC OFF uses RATE; a note division overrides free RATE. LFO DEST is PIT/FLT/SHP/AMP. The matrix can add routes on top.

**Gentle motion:** select a pad, LFO DEST FLT a small positive amount and PIT zero, then set a slow RATE with TRIG FREE. For tempo-locked motion choose LFO 2 SYNC. Hold LFO while sweeping a sound knob for a temporary excursion; release restores it. LFO + OCT+ asks for the all-track blessing instead.

<!-- PAGE -->
## 13. The arpeggiator procession

A chord becomes a procession when its notes take turns.

ARP K1 MODE, K2 RATE, K3 OCT (1-4), K4 GATE. RATE choices include 1/4, 1/8, 1/16, 1/32, 8T, 16T, 1/2, 1/1, 2BAR, 4BAR. Defaults are MODE OFF, RATE 1/16, OCT 1, GATE about 50%.

| Mode | Musical ordering |
| --- | --- |
| UP / DN / UPDN / DNUP | Ascending, descending, or alternating traversal. |
| RND / ORD | Random pick; or order notes were played. |
| REPEAT | Repeats the last note; it is not a steady sustained chord. |
| UP+8 | Ascending with octave treatment. |
| CONV / DIVG | Notes converge from the extremes or diverge from the center. |
| PINKY / THUMB | Alternating a high/low anchor with the other notes. |
| WALK / CHORD | Walking traversal; or chord-oriented steps. |

ARP 2: K1 SWG (0-100), K2 PROB (0-100%), K3 HOLD OFF/ON, K4 ORD NOTE/PLAY. HOLD remembers released notes. A fresh chord replaces the released latch; releasing HOLD clears the latch when no physically owned notes remain. The held input follows current scale/transposition mapping where applicable.

**Internal clock:** an enabled arp with held notes runs without PLAY. To hear a steady drone, select MODE OFF before enabling HOLD. To stop an internal arp, release keys, HOLD OFF and/or MODE OFF; do not rely on transport stop.

**External USB/TRS clock:** select that source on CLOCK and supply clock/transport from the controller. Stop releases the external-clock arp's sounding note but preserves its HOLD chord. A subsequent clock start can play it again. A plain held oscillator drone is not a transport sequence.

TENS/EVOL can animate the timbre of arp voices too. Very short gated notes can repeatedly fall silent and restart the drone state, so a long continuous pad is a clearer way to hear a slow tension build.

<!-- PAGE -->
## 14. The long devotion: DRONE

Blessed is the note that knows how to stay.

<!-- IMAGE drone -->

The host-rendered screen illustrates labels and layout; it is not a photo or live telemetry from Sparky's instrument. Tap ARP until DRONE. The page belongs to the selected track.

| Knob | Default | Meaning |
| --- | --- | --- |
| K1 HOLD | OFF | With MODE OFF, keep a steady played chord after release. With an arp on, retain its input chord. No notes are created by this switch alone. |
| K2 EVOL | 0% | Depth of smooth random tonal movement, gentle per-voice detune and amplitude breathing. |
| K3 TENS | 0% | Target intensity: opens tone/brightness/resonance, spreads pitch and deepens/speeds movement according to engine. |
| K4 RAMP | OFF | Rate toward TENS: OFF or 1, 2, 4, 8, 16, 32 bars. |

The random walks wander smoothly while voices are active. They stop in silence and restart from the base sound. TENS can alter the sound with EVOL at zero. It pushes track DIST only when distortion is already nonzero; it does not switch distortion on from zero. The engine's selectors and discrete models are not randomly swept.

DRUM is excluded. SLICE retains its discrete source/mode/slice choices and has no dedicated natural-parameter targets in the drone map; the generic voice modulation paths may still apply. Changing engines can briefly change the character of its movement. Different engines respond to filter/shape routes differently.

HOLD does not sustain a plucked envelope, loop a one-shot sample, or press PLAY. A physically played chord's new latch replaces the previous released chord; let all keys go before changing chords/tracks. HOLD is the same parameter as ARP 2's K3.

<!-- PAGE -->
## 15. Tension and slow-burning hymns

Raise the candles gradually; leave yourself a way home.

RAMP sets the rate for a **full-scale tension change**, not a guaranteed duration to every target. At 120 BPM, 8 bars are 16 seconds for 0 to 100%. A 50% target from zero takes roughly 8 seconds. A smaller target or a smaller fall takes proportionally less. TENS downward follows the same rate. OFF makes a prompt, smoothed change.

With numbered RAMP, a drone starting from silence begins at zero tension. Once a voice remains active, turning TENS sets a new goal rather than restarting a timed animation. Timing uses global BPM; it is not a count of sequencer notes or the track's DIV. Let the BPM set the speed of this slow ascent.

### A breathing pad

Load ANALOG SOFT PAD; CHRD OFF; ARP MODE OFF. Set HOLD ON, EVOL 20%, TENS 0%, RAMP OFF. Play/release two or three notes. Listen for at least a minute before raising EVOL. Start below half depth; high tension and resonance can change perceived level.

### A slow rise

On that pad choose RAMP 16 or 32, then TENS 40%. Leave the chord sounding. Bring TENS toward zero to descend. Use RAMP OFF when you want a prompt return. Set EVOL independently: it is not automatically zeroed by TENS zero.

### A vocal or bowed bed

Load VOICE CHOIR AAH, or PHYS BOWED METAL/DRONE STRING. Set MODE OFF and HOLD ON after loading. Start EVOL 10-20%, TENS zero. PHYS has a three-voice cap and model-dependent BOW controls; start with one or two notes. A resonator can decay despite a held gate; choose a sustained preset rather than forcing a pluck.

### Return to the original drone tone

Release keys, HOLD OFF. RAMP OFF, TENS 0%, EVOL 0%; remove any active DRIFT route too. Let tails end. Reload the intended preset if you changed its actual knobs. Jangada's hold-ARP DRONE OFF / SILENCE gesture and auto-latched named drone presets are not part of this build.

<!-- PAGE -->
## 16. Invisible hands: modulation and DRIFT

A little movement can turn a held note into a landscape.

Tap LFO to MOD. **K1 selects one of four slots; K2 selects SRC; K3 selects DST; K4 selects AMT.** Each track has four slots. SRC OFF, DST OFF or AMT zero makes that route inactive. Amount stores -64 to +63 and displays roughly -100% to +98%; negative depth reverses a route.

| Source | What it supplies |
| --- | --- |
| LFO / ENV | Track LFO, or a voice's amplitude envelope. |
| VEL / KEY / RAND | Note velocity, pitch relative to C4, or new per-note randomness. |
| MODW / AT / EXPR | MIDI CC1, channel aftertouch, CC11. They do not create notes. |
| S&H / SLEW | A value per LFO cycle; or a linear transition from the previous cycle's value. |
| DRIFT | The drone's first smooth bipolar random walk, per track. |
| MAC1-MAC4 | Four shared, positive 0-100% song values. |

Destinations: PITCH, CUT, SHP, AMP, PAN, DIST, CHO, DLY, REV, RATE, VIB, the eight engine parameter positions, and DEPTH (LFO depth). The screen names engine destinations for the current engine. Fixed ENV DEST and LFO DEST routes add alongside the matrix.

**DRIFT at EVOL zero:** choose an unused slot, DRIFT -> PAN with a small amount, listen in stereo. An active nonzero DRIFT route starts the walks even with EVOL/TENS zero; it need not apply the automatic drone depth. Clear the slot to remove it. EVOL zero alone cannot turn it off.

PITCH at full depth spans musical intervals, not merely a few cents; start small. Engine parameter destinations can include selectors: choose continuous targets such as CUT or tone level when seeking smooth movement. AMP and DEPTH routes act as multiplicative gates: a zero unipolar source with positive depth can close them, rather than merely subtracting an offset.

<!-- DIAGRAM mod -->

The screen and editor show your starting knob value; listen for the movement around it.

<!-- PAGE -->
## 17. Four shared blessings: macros

One gesture can open several stained-glass windows.

LFO -> MACRO places MAC1-MAC4 on K1-K4. Values default to zero, store 0-127 and display 0-100%. They have no fixed effect until assigned as a matrix source. Assignments are per track, while the four values are shared across the song.

### One knob for a shared rise

1. On T1 MOD, select a free slot; SRC MAC1, DST CUT, a small positive AMT.
2. On T2 MOD, assign MAC1 to a modest REV send amount.
3. On MACRO, turn K1. One gesture now opens T1 and increases T2's reverb send.
4. Set K1 back to zero to remove those positive-source offsets. Base settings and limit clamps still apply.

A destination already at its maximum has little room to move. Use lower base cutoff/send values before building a macro. For positive MAC -> AMP depth, zero can attenuate/silence instead of returning a neutral sound; avoid AMP for a first assignment.

UnholyUnion **saves macro values in its project format** and loads them with that project. This differs from Jangada's live macros, which its README says stay outside the project. Old imports initialize missing macros to zero. Assignments reset with a factory sound load because the matrix is part of the sound; shared values survive that sound load.

The Ritual Room links a performance macro desk with four shared sliders. It moves the blessings you have assigned in MOD; it does not choose their targets. Immaculate Permutation sets up Sanctuary, Echo, Halo and Procession for you.

**Not the FX layer:** holding FX exposes FILTER, CRUSH, THROW, DEPTH. Those temporary performance controls are a different system. MIDI CC16-19 are not prewired to MAC1-MAC4 in this merge; Jangada's fixed macro CC mapping was not imported.

<!-- PAGE -->
## 18. Write a small sermon: sequencing

A few well-placed notes can preach for hours.

Each track has up to 64 steps, initially LEN 16. **To shorten a loop: hold SEQ until SEQ TOOLS opens and turn K1 LEN while holding. STEP K3 LEN is only a note duration.** Hold SEQ for the tools layer: K1 LEN (1-64), K2 DIV (1/4 through 4BAR/short triplets), K3 SWING, K4 GATE. These are per-track timing; different lengths/divisions can make polymeter. PLAY runs all tracks; loading a sound does not load its suggested phrase.

### Step record a melodic track

1. Select a synth track, a sound, CHRD OFF and ARP MODE OFF. Stop transport.
2. Tap SEQ until STEP. Tap REC to arm step entry while stopped.
3. With CHORD ENTRY HOLD, play a note or up to four simultaneous notes; release all to advance one step.
4. Use K1 or PRESETS to choose a step. EDIT clears that step and advances. Disarm REC when finished, then PLAY for playback only. To leave a rest, skip an empty step with K1/PRESETS; if occupied, EDIT clears it and advances. Merely moving the cursor does not clear existing notes.

CHORD ENTRY ADD instead adds/removes individual notes without advancing on release; move with K1/PRESETS. Mono/legato/unison sounds retain one note rather than four. One-key chords can write their tones in POLY. Changing to another sound retains the sequence and common-parameter motion.

| STEP knob | Operation |
| --- | --- |
| K1 STEP | Cursor within LEN. |
| K2 NOTE | Transpose all notes in the step; an empty step gets the last note. |
| K3 LEN / TIME | Extend a note with following ties; stops before another note/end. A value stuck at1 can mean NOTE AHEAD or END OF PATTERN, not a fixed sixteen-step loop. On an empty/tie/rest context choose its time type. |
| K4 FLAG | None, accent, slide, or accent+slide. |

### Record live

Outside stopped STEP entry, REC arms the selected track and can start transport. Play the panel or incoming MIDI into a loop. Select another track to overdub there; check REC indications because arming is per track. With an arp on, its generated notes can be recorded. HOLD latches alone are not a saved sequence.

Hold REC for CLEAR, CLICK, COUNT-IN and CLICK LEVEL. Its CLEAR erases selected-track steps/motion without a dialog but has supported undo; do not use it merely to stop notes. COUNT-IN works from internal clock, not external clock.

<!-- PAGE -->
## 19. Chance, ratchets and the spaces between

Let the congregation breathe; silence belongs in the score.

SEQ -> DETAIL shares STEP's cursor/grid. PRESETS walks the cursor; on DRUM a white key selects a step. The four knobs edit the step's playback properties rather than its pitches.

| Knob | Range | Default / consequence |
| --- | --- | --- |
| K1 CHANCE | 0-100% | 100%. Skipped steps preserve the stored notes. |
| K2 RATCH | x1-x4 | x1. Several hits fit within that step. |
| K3 NUDGE | -8 to +7 sixteenths of a step | 0. -8 is half a step early; +7 is 7/16 late. |
| K4 VEL | 1-127 | 96 for manually entered/default note steps. |

EDIT on DETAIL restores these four to 100%/x1/0/96 and leaves the notes. REST/empty steps do not take note-only detail edits. An accented step/hit plays at 127 even if VEL is lower. All nonaccented drum hits on the step share its velocity; this is not per-lane velocity.

The AUTOMATION list's QUANTIZE row controls whether NUDGE plays: ON forces the grid; OFF uses stored nudges. A dimmed nudge may be inactive because quantize is on, there is no note, or ratchet behavior supersedes it. Live recording stores timing offsets even when quantized playback is selected.

**Try:** a sparse PLUCK sequence; lower one step's CHANCE to 75%, use x2 on another, move a third slightly late and turn QUANTIZE OFF. Save the project once it feels right. This is generative variation of an existing pattern, not a separate algorithmic composition engine.

Global swing and the track's swing combine in playback. RATE/DIV describe rhythmic lengths rather than a literal oscillator frequency. Delay and envelope time lists have extra divisions; don't assume every timing control offers the same choices.

<!-- PAGE -->
## 20. Remember the gestures: locks and automation

Teach a phrase its own little ritual.

A **lock** temporarily substitutes a parameter on one step. An **automation event** holds its value until the next event. They share **128 records across four tracks**, separate from each step's chance/ratchet/nudge/velocity fields.

On STEP/grid, hold a step and turn K1-K4 to lock the corresponding sound parameter. The roll uses the most recently selected sound-page mapping; read the displayed parameter before editing. PRESETS with a step held edits its nudge. EDIT while a step is held clears its locks. A grid hit being held for a lock is retained rather than removed on release.

AUTOMATION provides a reviewable list:

| Control | List operation |
| --- | --- |
| K1 / PRESETS | Select row. |
| K2 | Select/move record's step, where applicable. |
| K3 | Select record parameter; on +ADD choose parameter or CHANCE/RATCH/NUDGE/VEL. |
| K4 | Value; PLAY and QUANTIZE rows use ON/OFF. |
| OCT+ | Add selected record; toggle LOCK/AUTO on a record; CLEAR on PLAY; show/hide VEL rows. |
| EDIT | Delete record or restore the selected detail field's default. |

PLAY OFF in this list disables track automation while preserving its records. CLEAR asks before removing locks/events; it leaves step-detail fields. Save held undoes supported edits. Song playback can refuse edits with STOP TO EDIT. AUTOMATION FULL means the shared record pool is occupied.

**Hold SEQ tools:** white keys F3 CLEAR, G3 REVERSE, A3 SHIFT left, B3 SHIFT right, C4 RANDOM, D4 COOK. On DRUM E4 BEAT; lane actions G4 CLEAR, A4 REVERSE, B4 FILL, C5 RANDOM. Black keys choose drum lane. RANDOM builds a new beat or scale notes; COOK changes a pattern a little. Work affects steps within LEN. Reverse/shift move locks and motion with the steps. SAVE held undoes the last tool; OCT- restores the layer's opening state.

FILL here is a lane-population tool, not Jangada's per-step FILL/NO FILL performance conditions. Those conditions and its 12-locks-per-track architecture are absent.

<!-- PAGE -->
## 21. Percussion for the less contemplative

Even a solemn congregation may occasionally require a kick.

Select DRUM through the EDIT layer on any track. It is an engine, not a special global drum part. In SEQ STEP its **16 white keys address the current page's 16 steps**, not musical notes. The first eight black keys select KICK, SNARE, CLAP, HATCL, HATOP, TOM, RIM, BELL. The remaining black keys provide ACC and page navigation. Up to four pages cover 64 steps.

On the grid K1 selects STEP, K2 LANE, K3 sets HIT on/off, K4 sets ACC on/off; DETAIL uses its own four playback properties. Tap a white step to toggle its selected lane hit. Hold ACC while editing hits for lane accents. A lane key can audition a drum; record from its intended input context rather than expecting white grid keys to play pitched sounds. General MIDI input uses the engine's lane map; the routing channel is the track's assigned channel, not an automatic channel 10.

EDIT -> LANES sets levels for lanes 1-4; LANES 2 for 5-8. Holding EDIT exposes eight black-key lane mutes. These performance mutes keep the pattern running, are not saved/recorded, and clear on a sound/project load. OCT- in that layer restores the prior mute state. MIXER MUTE, in contrast, is the track's own saved parameter.

The visible kits are STD and 80/10/66/55/77. Several raw kit IDs are compatibility aliases and are skipped in ordinary browsing. DRUM's voices are synthesized; this build does not have Jangada's RUST, FORGE, PISTON, HURT, MANGUE or 32 extra kits.

**Easy rhythm:** select DRUM, hold SEQ and press E4 BEAT, release. Set LEN 16/DIV 1/16, then PLAY. Lower the track level before combining it with the drone/arp recipe. The tool is a Felucca beat generator; selecting a kit does not import Jangada's named factory beat.

STOP halts sequence playback, while one-shot drum tails and effects may ring. HOLD/EVOL/TENS do not turn this engine into a drone. To remove a rhythm, clear only the intended track after saving; muting is the reversible performance choice.

<!-- PAGE -->
## 22. Arrange the service: songs

Put your verses in order, then leave room for an encore.

GLO opens SONG. A song holds up to **16 sections**. Each section chooses, for each track, that track's pattern/timing/motion from project A-D, or '-' for no sequenced pattern. Current sounds remain: selecting another section's pattern is not a wholesale sound change.

| Knob | SONG role |
| --- | --- |
| K1 SECTION | Existing row or +ADD. |
| K2 TRACK | Which row lane to edit. |
| K3 PAT | A-D or '-' for the selected lane; on +ADD a turn creates a section. |
| K4 REPS | 1-16 loops of the section's clock track. |

White A3/B3/C4/D4 keys choose A-D for the selected lane on SONG. PLAY on SONG starts the chain; OCT+ also invokes its current PLAY/STOP action. Save a project to keep the chain. Stop the song before rewriting its patterns.

**Section length:** the first non-silent track in a section is its clock track; track 1 when used. REPS counts that pattern's loops. With all lanes silent, a 4/4 bar is used. Every new section starts its lanes at step 1. A '-' lane silences its sequence and restores its own automation base; live keys and arp still work because its sound remains.

**Try:** save a bass pattern and drum pattern in A, variants in B. Create two rows with T1/T4 A, then T1/T4 B; use '-' for an empty sequence on a drone track. Check track lengths before increasing repeats. A held drone can coexist with this arrangement but is not rebuilt from saved held notes.

SAVE -> TOOLS has deletion of the selected section and clearing the song, with confirmation. Distinguish CLEAR PATTERN, INIT SOUND, DELETE SECTION and CLEAR SONG on this page; these target different data. Stop first and read the confirmation.

<!-- PAGE -->
## 23. The mixing altar and effects

Let the reverb bless the sound without swallowing the sermon.

<!-- DIAGRAM audio -->

MIXER K1 LEVEL, K2 PAN, K3 REV send, K4 MUTE edits the selected track; ALGORITHM chooses the track. Holding GLO places T1-T4 levels on K1-K4. Its first four black keys toggle track mutes; first four white keys solo those tracks while held, C4 unmutes all, D4 MIDI LEARN, F4 taps tempo. These are the Felucca key map, not Jangada's numbered fill/solo map.

FX first page: K1 DST (distortion amount), K2 CHO, K3 DLY, K4 REV sends. DIST is the inherited track distortion, not Jangada's selectable SOFT/FUZZ/FOLD/CRUSH/RING DIST page. Effects can make apparent level grow; start with modest sends and feedback.

SLICER offers OFF/GATE/STUT, pattern, rate, depth. It gates or repeats material in rhythm; it is separate from the SLICE engine. Six rates include 1/8, 1/16, 1/32 and their triplets; 16 stored pattern shapes are available. STUT records into a short buffer and some live effects borrow that memory.

INSERT K1 type, K2-K4 type-specific controls; INSERT 2 K1 dry/wet MIX. Types: OFF, SOFT, HARD, FOLD, FUZZ, CRUSH, PHASR, FLANG, CHOR. Drives expose DRIVE/TONE/LEVEL. CRUSH exposes BITS/RATE/LPF (1-16 bits, nominal rates 689 Hz-44 kHz). Modulation effects expose RATE/DEPTH/FDBK. DISP is absent. OFF bypasses the insert. Insert settings belong to the sound and support motion/locks.

Global DLY K1 TIME, K2 FDBK, K3 COLR, K4 MIX. Shared REVERB K1 TYPE ROOM/SPRING/HALL, K2 SIZE, K3 DAMP. HALL is the fresh-start default; a loaded project keeps its type. Global CHORUS K1 CRT, K2 CDP.

Delay memory holds about 1.49 seconds; long divisions at slow tempos are capped, so 4BAR is not a promise of a multi-second loop. Dotted 1/4D/1/8D/1/16D are included. Global FX changes affect all tracks sending to that bus; lowering one track's REV does not change the room itself.

<!-- PAGE -->
## 24. Performance miracles and temporary excursions

Step out, make a little trouble, and return with grace.

Hold FX for the keyboard effect map. White keys invoke the assigned performance effects, black keys mute tracks 1-4. Default effects include short repeat, reverse, low/high-pass filtering, tape stop, freeze, octave harmonizer with shimmer, flanger/phaser and reverb/echo throws. They act on performance audio, not as new engine parameters.

Its K1-K4 are **FILTER, CRUSH, THROW, DEPTH**. FILTER sweeps low-pass left or high-pass right; CRUSH degrades resolution; THROW pushes delay/reverb sends; DEPTH controls buffer/modulation effect mix. With harmonizer active, the depth role follows that effect. These controls are not the four MAC values and not Jangada's FILT/DUST/DUCK/TAPE quartet.

Hold a white effect key in the FX layer and turn PRESETS to assign another effect; EDIT restores that key's default. The settings retain the map. The on-screen map is the best guide after remapping; do not memorize a default screenshot as an immutable keyboard chart.

With FX LATCH OFF, letting keys/button go restores temporary effects and controls. FX LATCH ON makes effect keys toggle and knob values remain; **FX + OCT- clears the latched performance effects/macros**. Another page's dialog/menu can also clear performance state. Reverb/delay tails can persist after the source effect ends.

REV THROW/ECHO THROW default to D5/E5. They lift sends while held, then leave the stored send values intact; echo throw raises low delay feedback to 70% while active, not above that. A remapped key uses its current assignment. Short-loop constraints can dim unavailable effects at very slow tempos.

**Momentary sound edit:** hold LFO, sweep a sound/FX knob (including selected-track MIXER controls), release to restore. Release restores the starting sound. LFO + OCT+ instead applies the gentle all-track blessing. The UI records base parameters, not the temporary sweeps. This is useful for auditioning a brighter drone without losing its starting point.

<!-- PAGE -->
## 25. Name and save your hymns

When a revelation feels like yours, give it a name.

A factory preset is an engine's starting sound. A user preset stores a named sound and its supported pattern/FM patch data; a project stores the four-track music and shared settings. A project is the reliable choice for a drone-plus-arp setup. Neither captures physically held input notes as a ready-to-sound latch.

| SAVE page | What to do |
| --- | --- |
| USER | K1 selects one of 32 slots. K2 LOAD, K3 ERASE, K4 SAVE are actions selected by turning then confirmed with OCT+. |
| PRESETS | K1 sound list, K2 engine, K3 favorites, K4 category/list. Loads as you browse; filters change the list. |
| PHRASES | K1 phrase, K2 LOAD; OCT+ loads into the selected track. Edited pattern replacement may ask confirmation. |
| PROJECT | K1 slot A-D, K3 LOAD, K4 SAVE; select action then OCT+. |
| TOOLS | Clear selected pattern, initialize sound, delete selected song section, clear song; read each confirmation. |

**Quick user save:** stop, tap SAVE to USER, choose an empty slot with K1, OCT+ from the initial quick-save state, then OCT+ on NAME. If selecting an explicit action, turn K4 for SAVE first. An occupied slot adds overwrite confirmation. EDIT on USER/PROJECT opens rename, not a sound page.

**Project save:** stop transport, SAVE taps to PROJECT, select A-D, turn K4 to SAVE, OCT+. Confirm overwrite if shown, then type a name or accept the suggested name and OCT+. Keys type names in NAME; they do not play. OCT- cancels. Project load replaces the working music; turn K3 LOAD, OCT+ after choosing a used slot.

Factory loading retains level/pan/mute, arp/HOLD, scale/chord and sequence/timing settings; matrix, envelope, engine and added EVOL/TENS/RAMP reset to that sound. Shared macros and global FX remain. User loads/projects have their own stored values. Loading a sound can release existing notes and clear temporary drum-lane mutes; replay the intended chord.

<!-- PAGE -->
## 26. Keep your scriptures: saves and backups

The muse is generous. Your filing system should be too.

RESTORE LAST ON keeps a working autosave separate from projects A-D. It saves after you stop and leave the instrument idle; allow a quiet minute before powering off. For a keeper, make a deliberate project save rather than trusting your final knob turn to autosave.

UnholyUnion saves belong with UnholyUnion. Do not restore them into Felucca or Jangada. Keep your old music separately if you move between firmwares.

### Gather the scriptures

Use the editor's complete backup to gather the current music, projects A-D, user sounds, samples and settings. Keep the original FM6 bank .syx separately, along with sample source files. A single exported project carries its music and FM6 patches, but not your whole sample library or every saved bank.

The UnholyUnion editor is for this firmware; use a stock-compatible backup tool for stock firmware. Changing firmware does not magically preserve every stored sound.

Sending a sound to the instrument lets you hear it. Saving to a named slot keeps it there. Exporting keeps a copy on the computer. Practise with an empty slot, and read overwrite confirmations before accepting them.

<!-- PAGE -->
## 27. The Choir Loft: web editor

A larger window onto the same congregation.

Open **The Choir Loft**, the editor linked from the Ritual Room, on supported desktop Chrome/Edge, HTTPS or localhost, with Web MIDI SysEx enabled. Connect exactly one intended FM-1 and close other applications contending for its ports. 

The Choir Loft follows the controls of the connected instrument. It provides sound/track editing, sequence grid, mixer, library and user slots, projects/song, FM6 patch/bank editing, samples, display/settings and backup operations. EVOL, TENS and RAMP shape each drone; the performance macro desk gives the four shared blessings room to shine.

### Ordinary editor workflow

1. Connect and inspect the reported identity/version and chosen track.
2. Read the current state before editing. Sending a patch affects the instrument immediately.
3. Adjust sliders; click then use wheel/arrows for fine steps, Shift for larger steps, double-click to reset supported controls.
4. Export to the computer, or explicitly store in the intended hardware slot. A local library edit is not automatically a permanent device save.

The FM6 editor imports a single DX7 .syx voice or a standard 32-voice bank, edits the whole six-operator patch, and sends a selected voice to a track. The track then owns that patch (SLOT OWN). Sending a complete bank replaces the separate 32-voice bank after transfer validation. There is no B33-B64 bank in this build.

Use the UnholyUnion editor for FM6 transfers. Keep the original bank file so your favourite voices have a second home.

On iPad/Safari the guide is readable, but live editor, macro desk and installer MIDI transport are unsupported here. Use the physical panel or a supported desktop host. Find the editor in the hosted Ritual Room.



The Projects tab also offers Immaculate Permutation. Choose key, scale, rite, stir and tempo, then Reveal. Leave Seed blank for a fresh roll. Export scripture keeps the full current project; Receive scripture loads it into the working session. Save A-D keeps it on the instrument. The Evolve and LFO blessing gestures are on the physical panel.

<!-- PAGE -->
## 28. Samples, fragments and borrowed echoes

Turn a small recording into a new place to dwell.

SAMPLE, GRAIN and SLICE share the three user sample slots USR1-USR3. Built-in sets are PIANO, FLUTE, SAX, plus BREAK material for SLICE. 

The browser Samples section accepts files or records a **computer input**, then trims/normalizes the material for upload. It supports up to 16 zones/sounds and approximately 7 seconds per slot depending on how it is prepared. Record through the computer input, then send the prepared sample to the FM-1. The FM-1 does not record an external analog input itself.

### A reusable texture

1. Preserve a source WAV and any current slot export/backup.
2. In the matched editor choose an unused user slot, select audio or record a computer input; stop and inspect it.
3. Trim waveform ends; zoom for detail. Assign supported zone roots/ranges as needed and upload intentionally.
4. Select SAMPLE SET or GRAIN SRC to that USR slot. Missing/invalid sources show NO SAMPLE and may play a fallback sine.

For SLICE choose SRC USR1-USR3, DIV equal divisions/AUTO/MAN. EDIT -> SLICES edits the markers. K1 selects slice or final END, K2 moves its start. Select K3 SPLIT or K4 JOIN by turning, then OCT+ performs it. OCT- cancels the action or returns HOME. The first manual edit selects MAN; table storage occurs after leaving and stopping as required.

BREAK/PIANO show their slices but are not manually rewritten through this page. Slice start trims the head; END trims the tail. Manual sources support up to 32 slices. A key picks/plays its slice; START shifts the first key's slice selection. Source MODE ONE/GATE/LOOP governs playback and envelopes; HOLD cannot manufacture endless sample material.

<!-- PAGE -->
## 29. MIDI: invite the wider choir

Give each guest the right channel and let them sing.

USB MIDI and TRS MIDI input route through MENU > MIDI > MIDI IN. CH1-4, CH5-8, CH9-12 or CH13-16 assigns that block of four channels to T1-T4. Channels outside the chosen block are ignored for notes, CC, bend, aftertouch and program change. SEL maps all input channels to the selected track; multiple channels can share it, with controller ownership handled per input channel.

Panel keys send USB MIDI on their track's channel in the selected block. The stored sequencer and arpeggiator play the internal sounds. Do not expect the sequencer/arp to drive a modular MIDI interface as an outgoing note generator; use an external sequencer sending MIDI into the FM-1 instead. Its analog output carries audio, not CV/gate.

| MIDI message | Musical role |
| --- | --- |
| CC5 / 7 / 10 | Glide / level / pan. |
| CC71 / 74 | Engine-dependent resonance / brightness; unsupported engine destinations ignore them. |
| CC72 / 73 / 75 | Release / attack / decay. |
| CC91 / 93 / 94 | Reverb / chorus / delay sends. |
| CC1 / CC11 / channel AT | Mod wheel / expression / aftertouch sources for matrix. |
| CC64 | Sustain pedal; drum hits ignore sustain/bend. |
| Pitch bend, RPN 0 | Bend sensitivity up to 24 semitones plus cents; not MPE per-voice expression. |
| CC120 / 123 / 121 | All Sound Off / All Notes Off / Reset Controllers. |

CC120 silences the routed target track and discards note ownership; CC123 releases notes normally and honors sustain. CC121 resets controllers/pedal while keeping bend sensitivity; it does not reset sound parameters. Apply on each routed channel for a multi-track panic. Continuing sequence/arp playback can generate later notes, so stop playback and release latches as well.

MIDI LEARN: hold GLO and press D4, turn the instrument parameter knob, move an eligible CC control on your controller. Up to 16 mappings save with device settings. OCT- clears the picked mapping; OCT+ or GLO+D4 ends learning. MENU > MIDI > LEARN CLEAR clears all. Learned CCs can override their standard map; reserved controller functions cannot be learned.

<!-- PAGE -->
## 30. Set the pace of the procession

A shared clock lets different instruments breathe together.

CLOCK is HOME's third view: BPM, SWG, CLK INT/USB/TRS. BPM range is 40-240, default 120. Internal tempo is shared; each track retains its own DIV and arp RATE. A tempo-synchronized modulation/effect may therefore follow a different note division from the sequence.

External clock uses realtime pulses and Start/Continue/Stop from the selected input. Start returns to step zero; Continue preserves the current position; Stop halts transport. Clock interpolation and measured tempo follow incoming pulses. If no external source is running, a silent arp may be waiting for clock rather than broken; use CLK INT for a stand-alone recipe.

COUNT-IN is internal-clock only. Global and per-track swing interact. Long envelope/reverb/drone state is not a recorded transport lane; a plain drone can continue when a sequence stops. External Stop releases the external arp note but keeps its latched input chord for later restart.

### Program Change without guessing numbers

Programs are zero-based within the selected track's engine. DRUM programs 0-5 select STD, 80, 10, 66, 55, 77 in the documented program order. FM6 programs 0-7 select factory voices; 8-39 select valid B1-B32 bank voices. Invalid/out-of-range programs are ignored, never wrapped. Bank Select is not a second-bank selector here. Other engines follow the visible factory-preset order, skipping aliases; Program Change does not switch engines.

A Program Change retains sequence and track settings as ordinary sound browsing does, while loading the new sound. SAVE held supports undo of a load. Program numbers displayed one-based by a controller can be off by one: confirm with one known sound before sending a bank of changes.

### Modular-minded setup

Use a MIDI-capable external clock/sequencer into USB/TRS, route separate channels to the intended tracks, and feed FM-1 audio through an appropriate audio-level input/interface in your modular system. The firmware does not expose CV/gate I/O, audio-input effects processing, or a new clock-output port. Match electrical levels/adapters to your actual hardware; use the correct TRS MIDI adapter for your instrument.

<!-- PAGE -->
## 31. Dress the chapel: display and controls

For shameless splendour, choose **COLOR → GILT SIN**: black velvet, blood-crimson surfaces, silver lettering and gold values. Our gaudy new vestments are optional; your saved colors stay yours.


Choose the light by which you prefer to play.

Hold HOME for the menu. ALGORITHM changes the tab; PRESETS changes row; any K1-K4 or OCT-/OCT+ changes its value. HOME closes and saves normal preference changes. 

| DISPLAY row | Values / use |
| --- | --- |
| COLOR | GREY, GREEN, AMBER, ICE, VIOLET, ROSE, PAPER, HI-CON, NIGHT, MONO. |
| STYLE | FLAT filled cards / LINE divided regions. |
| LARGE | OFF/ON; larger labels/cards, not extra parameters. |
| ANIM | OFF/ON/IDLE. IDLE adds gentle lights after inactivity. |
| LEDS | OFF, DIM LO, DIM HI, INV. DIM HI is the default idle glow. |
| SCREEN OFF | NEVER, 5/15/30/60 MIN; audio/MIDI keep running. First input wakes only. |
| SCOPE | OUT after MASTER / MIX before MASTER. |
| HOME | SCOPE / TRACKS / LEVELS. LEVELS makes K1-K4 the four track levels. |

| CONTROL row | Values / use |
| --- | --- |
| HOLD | 0.3/0.4/0.5/0.6 seconds; default 0.4. Layer threshold, not note HOLD. |
| KNOB ACCEL | OFF/ON; faster turns move farther in wide ranges. |
| FX LATCH | OFF/ON; toggled performance FX and retained knobs. |
| BPM LOCK | OFF/ON; prevent ordinary SELECT tempo changes. |
| SCALE LEDS | OFF/ON; scale/root indication, excluding own-map engines. |
| STEP PREVIEW | OFF/ON; stopped cursor moves audition a step once. |
| CHORD ENTRY | HOLD together/release to advance; ADD individually, advance manually. |

A dark screen does not mean silence or a failed update. Try one waking input and inspect the title. A control doing a different job may reflect HOME LEVELS, a locked layer or a modal action, not a broken knob. 

<!-- PAGE -->
## 32. Listening, connections and homecoming

Keep these settings close when the outside world calls.

| AUDIO row | Values / use |
| --- | --- |
| SPEAKER EQ | FLAT, LOWCUT, BASS+. Affects analog and USB too; use FLAT for clean recording. |
| USB LEVEL | MASTER or FIXED; FIXED ignores MASTER for USB capture. |
| CLICK | OFF, REC, ON; beat click while playing, analog only. |
| CLICK LEVEL | LOW, MID, HIGH. |
| COUNT-IN | OFF, 1 BAR, 2 BARS; internal-clock recording only. |
| TUNE | -50 to +50 cents; saved with project. |

| MIDI / SYSTEM row | Values / use |
| --- | --- |
| MIDI IN | CH1-4, SEL, CH5-8, CH9-12, CH13-16; project's routing. |
| LEARN CLEAR | OCT+ clears up to 16 learned CCs; row shows count. |
| USB SERIAL | ON/OFF. Changing can re-enumerate USB when menu closes; MIDI/audio connections can drop. |
| RESTORE LAST | ON/OFF; independent working autosave. |
| HELP | OFF/ON; brief footer hints. |
| CALIBRATION | Opens panel-label/encoder mapping procedure; changes preferences. |
| AUTO EVOLVE | OFF, 2, 4, 8, 12, 16, 24 or 32 bars; gently evolves the backing harmony while PLAY runs. |
| FACTORY RESET | Return the current session to Evening Vow; saved projects and presets remain. Read the confirmation. |
| INFO | Version, USB state and CPU reading. |
| ABOUT | Saints / Source: our foundations, gratitude and a QR to the Ritual Room; PRESETS scrolls. |

USB SERIAL can help if your computer has trouble finding the audio interface. Do not toggle serial during a firmware transfer, recording or a storage write; plan a reconnect afterwards.

Hardware calibration may be entered by its menu action or the documented OCT-/OCT+ power-on combination. It asks for the printed labels/encoders and stores the mapping. This is not a first-use requirement or a recovery mode; only use it if the observed panel mapping is wrong and you understand what it changes.

 TUNE and MIDI IN are saved with the project; most other menu preferences are device settings, not per-track sound controls.

<!-- PAGE -->
## 33. Silence, release and finding your way home

A peaceful ending is a musical skill too.

### A deliberate musical stop

1. Release panel and external keys; release the sustain pedal.
2. On each latched track, set HOLD OFF (DRONE K1 or ARP 2 K3). For an arp, set ARP MODE OFF.
3. Stop PLAY if sequences/song/count-in run. Internal arps and a steady drone are not necessarily stopped by PLAY.
4. Let release/effect tails ring, or lower MASTER for immediate listening silence. MUTE/MASTER is not erasure.

For MIDI panic, CC120 All Sound Off on each routed channel silences its notes; CC123 respects sustain and uses normal release. Stop generators too, because later events can make new notes. Release each track's HOLD latch when you want the drone to end. Do not substitute an update/recovery command for a musical panic.

### Strip back movement without wiping a project

On the selected track: RAMP OFF, TENS 0%, EVOL 0%; disable DRIFT matrix routes. Set shared MAC values to zero or remove routes that gate AMP. Disable other active LFO/ENV routes if needed. Clear latched performance state with FX+OCT- where applicable. Stop automation/transport before evaluating the base sound.

Load ANALOG SOFT PAD. Explicitly set ARP MODE OFF, HOLD OFF and CHRD OFF; retained track settings can still surprise you. On MIXER unmute and check level/pan; on ENV check that SUS is above zero. Play a key long enough for attack. This is a practical baseline, not a total reset of global effects, patterns or storage.

| Symptom | First checks |
| --- | --- |
| No sound | Audio monitoring/cable, master/track level, mute/solo, attack, AMP matrix/expression, held source/clock. |
| Stops when adding a track | Shared voice budget; reduce chord/unison/release and check engine cap. |
| HOLD but no long drone | No played note, SUS zero, one-shot/sample/model decay, arp still on. |
| EVOL zero but it moves | TENS, DRIFT route, engine DRFT, LFO/S&H/SLEW, macros or automation. |
| Sine instead of material | Missing/invalid USR source; inspect NO SAMPLE and sample upload. |
| Knobs do odd jobs | Layer/menu/name/action, HOME LEVELS, engine dynamic labels, calibration. |

<!-- PAGE -->
## 34. The choir of engines

Each engine has its own accent. Begin with a preset, then follow your ears.

Hold EDIT and turn K1 to choose an engine; K2 chooses its preset. Release EDIT before playing/editing ordinarily or turning ALGORITHM for another track. EDIT1 is the first four engine positions; EDIT2 the second four, with additional pages for applicable engines. HOME offers a curated four-control subset (unless HOME LEVELS overrides it).

The following tables follow EDIT1 and EDIT2, four knobs at a time. A dash marks a knob with no job on that page. Choose a factory preset as your starting point, then use the Musical role column to decide what to move. Turn time and brightness controls by ear; equal knob steps do not always mean equal changes in seconds or tone.

Some controls change their name or purpose with the selected model; follow the screen.

For an unfamiliar timbre, begin with the listed factory sound and a single note before adding HOLD, drone depth, effects or more tracks. Noise/chip aliasing and FM inharmonicity can be intentional; if notes disappear in a busy arrangement, reduce unison or shorten releases to give the parts room.

<!-- PAGE -->
## 35. ANALOG - a voice in the choir

The warm candle: pads, basses and a little resonant temptation.

Two band-limited oscillators, noise and a resonant state-variable filter. A practical first home for pads and bass.

**HOME K1-K4:** CUT, RES, ATK, REL. **Voice cap:** 8, within the shared eight-voice budget.

| Position / label | Musical role |
| --- | --- |
| EDIT1 K1: WAVE | Wave pair: saw, square, triangle, sine, PWM, hard sync or sub. |
| EDIT1 K2: DTN | Pair detuning in cents; with SYNC this becomes SYNC pitch offset (up to about two octaves). |
| EDIT1 K3: MIX | Balance of the pair; SUB relabels it SUB level. |
| EDIT1 K4: NOIS | Noise mixed with the oscillators. |
| EDIT2 K1: CUT | Filter cutoff; nonlinear frequency control. |
| EDIT2 K2: RES | Resonance; high settings emphasize the cutoff. |
| EDIT2 K3: DRV | Drive around the engine tone/filter path. |
| EDIT2 K4: KTR | Filter keyboard tracking. |

FILTER adds TYPE LP/BP/HP plus CUT, RES, KTR.  Try SOFT PAD; raise MIX/DTN gently and keep resonance modest.

**Factory starting sounds:** SAW LEAD, SOFT PAD, SQR BASS, PWM STR, ACID, SINE KEY, RAVE, SUB BASS, PLUCK, BRASS, WIND, STRINGS.

**Drone behavior:** MIX walks; tension increases RES/DRV.

<!-- PAGE -->
## 36. FM6 - a voice in the choir

The glass chapel: bells, electric keys and harmonics with a glint of mischief.

Six operators with a full DX7-style patch per track, rendered by the msfa-derived core. Engine knobs are offsets above that patch.

**HOME K1-K4:** MLVL, MRAT, MEG, SLOT. **Voice cap:** 6, within the shared eight-voice budget.

| Position / label | Musical role |
| --- | --- |
| EDIT1 K1: ALG | PAT at0 preserves patch algorithm;1-32 chooses another topology. |
| EDIT1 K2: FB | Signed feedback offset above patch feedback. |
| EDIT1 K3: MLVL | Modulator output-level offset: brighter/less bright. |
| EDIT1 K4: MRAT | Signed coarse-ratio offset for ratio-mode modulators. |
| EDIT2 K1: MEG | Signed modulator envelope-time offset; positive slows. |
| EDIT2 K2: VMOD | Signed modulator velocity-sensitivity offset. |
| EDIT2 K3: DTUN | Carrier pitch spread, not a transpose control. |
| EDIT2 K4: SLOT | F1-F8 factory patches, OWN, valid B1-B32 bank voices. |

Neutral macros preserve the patch. Use OPERATOR / OP ENV / OPERATOR2 for individual operators; see next reference note. There is one bank, no B33-B64. Start with PAD or BELL.

**Factory starting sounds:** TINE EP, BELL, FM BASS, BRASS, PAD, MARIMBA, ORGAN, PLUCK.

**Drone behavior:** DTUN walks; tension affects modulator level/detune.

<!-- PAGE -->
## 37. PHASE - a voice in the choir

The stained-glass choir: strings, bells and bright shifting colours.

Phase-distortion oscillators bend the phase of a cosine-derived wave. A second line can mix or ring-modulate.

**HOME K1-K4:** DCW, ENV, DTN, REL. **Voice cap:** 8, within the shared eight-voice budget.

| Position / label | Musical role |
| --- | --- |
| EDIT1 K1: WAVE | Primary phase-distortion waveform. |
| EDIT1 K2: WAVE2 | Optional alternating waveform (- disables alternate). |
| EDIT1 K3: DCW | DCW phase-bend depth: brighter/richer distortion. |
| EDIT1 K4: ENV | Local envelope influence on phase distortion. |
| EDIT2 K1: DTN | Detune of the second line in cents. |
| EDIT2 K2: LINE | Mix or ring interaction of the second line. |
| EDIT2 K3: SUB | Sine sub an octave below. |
| EDIT2 K4: - | Unused position; does nothing. |

ENV/LFO SHP influence the engine tone. Try STRING for a bed or BELL for metallic steps. There are seven active edit positions, not sixteen.

**Factory starting sounds:** BRASS, ORGAN, STRING, RESO, BELL, WIRE.

**Drone behavior:** DCW walks; tension affects DCW and detune.

<!-- PAGE -->
## 38. LOFI - a voice in the choir

The crooked hymn: grainy edges and charm that refuses to polish itself.

Quantized chip-style waves, optional stepped envelopes and wave RAM. Roughness is intentional; it is not necessarily a dropout.

**HOME K1-K4:** WAVE, DUTY, CRSH, REL. **Voice cap:** 8, within the shared eight-voice budget.

| Position / label | Musical role |
| --- | --- |
| EDIT1 K1: CHIP | Chip resolution/behavior mode, including STEP. |
| EDIT1 K2: WAVE | Pulse/triangle/saw/noise or wave RAM. |
| EDIT1 K3: DUTY | Pulse duty; WRAM relabels to WAV# selecting sixteen tables. |
| EDIT1 K4: CRSH | Amplitude/sample degradation; STEP relabels to DCY. |
| EDIT2 K1: SWP | Downward pitch sweep after the note attack. |
| EDIT2 K2: VIB | Local vibrato amount. |
| EDIT2 K3: ARP | Local chip arpeggio: OFF/OCT/MAJ/MIN; separate from track ARP. |
| EDIT2 K4: TONE | Output tone filtering. |

STEP uses its own stepped decay behavior, so the ADSR is not the only amplitude shape. Set local ARP OFF when demonstrating the steady-drone recipe. Start with WAVE BASS or STEP LEAD.

**Factory starting sounds:** PULSE LD, WAVE BASS, ARP 8BIT, WAVE LEAD, STEP LEAD.

**Drone behavior:** No table-selector walk; tension can push CRSH.

<!-- PAGE -->
## 39. SAMPLE - a voice in the choir

The borrowed echo: a recording becomes a playable voice.

Multisample playback from built-in PIANO/FLUTE/SAX or three shared user slots. Zones and loop metadata come from source preparation.

**HOME K1-K4:** SET, CUT, ATK, REL. **Voice cap:** 8, within the shared eight-voice budget.

| Position / label | Musical role |
| --- | --- |
| EDIT1 K1: SET | Choose a built-in sound or your own sample slot. |
| EDIT1 K2: TUNE | Sample pitch offset, semitones. |
| EDIT1 K3: BITS | Sample degradation / reduced bit treatment. |
| EDIT1 K4: LOOP | Allow source loop playback where source has loop metadata. |
| EDIT2 K1: CUT | Tone cutoff. |
| EDIT2 K2: - | Unused edit position. |
| EDIT2 K3: DRV | Drive amount. |
| EDIT2 K4: - | Unused edit position. |

Only six positions are active. Missing sources fall back to a sine and show NO SAMPLE. LOOP ON does not guarantee an arbitrary uploaded recording has an endless sustain. Preserve source files before upload.

**Factory starting sounds:** PIANO, FLUTE, SAX.

**Drone behavior:** No source sweep; tension can push DRV.

<!-- PAGE -->
## 40. VOICE - a voice in the choir

The wordless choir: vowels, whispers and voices without a sermon.

A glottal/formant voice for vowel pads, leads and whisper textures. Four resonances shape a voiced/noisy source.

**HOME K1-K4:** VOWL, BUZZ, BRTH, TALK. **Voice cap:** 4, within the shared eight-voice budget.

| Position / label | Musical role |
| --- | --- |
| EDIT1 K1: VOWL | Starting vowel position along the formant table. |
| EDIT1 K2: VOWL2 | Target vowel for the TALK transition. |
| EDIT1 K3: TALK | Transition time between vowels (nonlinear time index). |
| EDIT1 K4: SHIFT | Formant frequency shift, semitones. |
| EDIT2 K1: BUZZ | Glottal buzz/brightness and source tilt. |
| EDIT2 K2: BRTH | Breath noise; high settings approach whisper. |
| EDIT2 K3: Q | Formant resonance/quality. |
| EDIT2 K4: RAND | Per-note random vowel variation. |

Four-voice cap. Start with CHOIR AAH; the long envelope makes HOLD useful. TALK/RAND can cause motion with EVOL at zero; distinguish this engine behavior from DRIFT.

**Factory starting sounds:** CHOIR AAH, VOX LEAD, WOW BASS, WHISPER.

**Drone behavior:** BRTH walks; tension pushes BUZZ/Q.

<!-- PAGE -->
## 41. TRIO - a voice in the choir

The small congregation: three tones gathered into one sound.

Three chip-inspired oscillators with combined waves, hard sync and ring modulation into a multimode filter.

**HOME K1-K4:** CUT, RES, PW, INT2. **Voice cap:** 8, within the shared eight-voice budget.

| Position / label | Musical role |
| --- | --- |
| EDIT1 K1: WAVE | Oscillator set and sync/ring arrangement. |
| EDIT1 K2: INT2 | Oscillator2 interval, semitones. |
| EDIT1 K3: INT3 | Oscillator3 interval, semitones. |
| EDIT1 K4: DTN | Opposed oscillator detuning, cents. |
| EDIT2 K1: MODE | Filter mode LP/BP/HP/notch. |
| EDIT2 K2: CUT | Filter cutoff. |
| EDIT2 K3: RES | Filter resonance. |
| EDIT2 K4: PW | Pulse width; shape routes modulate it. |

INT2/INT3 change the chord-like spectrum of one voice; they do not create separate keyboard notes/tracks. Try CHIP CHOIR with low TENS for an evolving texture.

**Factory starting sounds:** FAT BASS, ARP LEAD, SYNC LEAD, RING BELL, CHIP CHOIR.

**Drone behavior:** DTN walks; tension pushes DTN/RES.

<!-- PAGE -->
## 42. WHEEL - a voice in the choir

The organ loft: draw the harmonics into the light.

Tonewheel additive organ with registration groups, percussion, contact click and rotary motion.

**HOME K1-K4:** REG, PERC, DRV, ROTR. **Voice cap:** 8, within the shared eight-voice budget.

| Position / label | Musical role |
| --- | --- |
| EDIT1 K1: REG | One of sixteen drawbar registrations. |
| EDIT1 K2: SUB | Signed adjustment of low drawbar groups. |
| EDIT1 K3: BODY | Signed adjustment of body drawbars. |
| EDIT1 K4: TOP | Signed adjustment of upper drawbars. |
| EDIT2 K1: PERC | Second/third-harmonic percussion variants. |
| EDIT2 K2: CLICK | Contact noise at note on/release. |
| EDIT2 K3: DRV | Per-voice drive. |
| EDIT2 K4: ROTR | Rotary OFF/SLOW/FAST. |

Percussion single-triggers when no other note is held. SUB/BODY/TOP are stepped drawbar offsets; drone walks deliberately avoid sweeping them. Start SOFT FLUTE or GOSPEL for a steady bed.

**Factory starting sounds:** FULL ORGAN, JAZZ PERC, GOSPEL, SOFT FLUTE, ROCK DRIVE.

**Drone behavior:** DRV walks/tension; no drawbar step sweeping.

<!-- PAGE -->
## 43. GRAIN - a voice in the choir

The incense cloud: fragments gather, drift and dissolve.

Overlapping windowed grains from built-in/sample-slot material. Texture depends on the source as well as grain controls.

**HOME K1-K4:** POS, SIZE, DENS, SPRD. **Voice cap:** 3, within the shared eight-voice budget.

| Position / label | Musical role |
| --- | --- |
| EDIT1 K1: SRC | Sample source shared with SAMPLE. |
| EDIT1 K2: POS | Center of grain extraction within the source. |
| EDIT1 K3: SIZE | Grain length index; from tiny flecks to longer clouds. |
| EDIT1 K4: DENS | Grain launch density (about1-98 per second). |
| EDIT2 K1: PTCH | Pitch offset, semitones. |
| EDIT2 K2: SPRD | Random source-position spread and timing variation. |
| EDIT2 K3: RAND | Random detune of grains. |
| EDIT2 K4: TONE | Tone cutoff/filtering. |

Three-voice cap and bounded grain pool. Start CLOUD PAD with moderate EVOL. Empty user slots produce a sine fallback. Large chords consume the shared budget even when individual grain texture is dense.

**Factory starting sounds:** CLOUD PAD, GLITCH, FROZEN, SHIMMER.

**Drone behavior:** SIZE walks; tension increases DENS/RAND.

<!-- PAGE -->
## 44. PHYS - a voice in the choir

The resonant relic: struck, bowed and ringing bodies.

Fixed-point physical models: modal resonator, plucked string, struck membrane and sympathetic strings.

**HOME K1-K4:** STRC/HARM/CHRD, BRIT, DAMP, POS/SYMP. **Voice cap:** 3, within the shared eight-voice budget.

| Position / label | Musical role |
| --- | --- |
| EDIT1 K1: MODEL | Choose MODAL/STRNG/MEMB/SYMP. |
| EDIT1 K2: STRC | Model structure; MEMB shows HARM, SYMP shows CHRD. |
| EDIT1 K3: BRIT | Brightness/exciter tone. |
| EDIT1 K4: DAMP | Resonator decay/damping behavior; higher values can ring longer. |
| EDIT2 K1: POS | Excitation position; SYMP shows sympathetic coupling SYMP. |
| EDIT2 K2: ACC | Velocity accent influence. |
| EDIT2 K3: BOW | Sustaining excitation BOW; MEMB shows BEND, SYMP shows BUZZ. |
| EDIT2 K4: EXC | Direct exciter contribution. |

Dynamic labels/ranges remain raw 0-127. SYMP CHRD walks OCT/5TH/4TH/MAJ/MIN/SUS/7TH/ROOT across that range. MEMB BEND is pitch drop, not bowing. Three-voice cap; no imported Brazilian/PIANO PODRE presets.

**Factory starting sounds:** BELL TREE, MARIMBA, PLUCK, BOWED METAL, KALIMBA, HAND DRUM, TOMS, DRONE STRING, HARP.

**Drone behavior:** BRIT walks; tension changes BRIT and model-dependent position6; never MODEL.

<!-- PAGE -->
## 45. NOISE - a voice in the choir

The wind through the rafters: breath, dust and beautiful disorder.

Analog noise/impulses or register-generated metallic tones through a morphing resonant filter.

**HOME K1-K4:** FREQ, RES, COLR, REL. **Voice cap:** 8, within the shared eight-voice budget.

| Position / label | Musical role |
| --- | --- |
| EDIT1 K1: MODE | ANLG/DUST/LFSR/META source behavior. |
| EDIT1 K2: COLR | Noise color white through pink to brown. |
| EDIT1 K3: FREQ | Filter frequency, still FREQ in register modes. |
| EDIT1 K4: RES | Filter resonance, morphing low-pass toward band-pass. |
| EDIT2 K1: TRK | Frequency keyboard tracking. |
| EDIT2 K2: DENS | Impulse density; register modes show LEN selecting register length/sequence. |
| EDIT2 K3: DRFT | Engine-specific slow drift; distinct from matrix DRIFT. |
| EDIT2 K4: CRSH | Degradation for ANLG/DUST; LFSR/META relabel this position CLK, a raw 0-127 semitone offset above the key. |

LFSR LEN choices L23/L20/L17/L15/L13/L11/L9/L7; META has 127/127B/93/63/63B/31/15/7 sequence choices.  DUST at zero DENS can be quiet. Try WIND/RAIN.

**Factory starting sounds:** WIND, RAIN, ARCADE, METAL.

**Drone behavior:** COLR walks; tension affects RES/DRFT.

<!-- PAGE -->
## 46. SLICE - a voice in the choir

The broken scripture: cut an echo into new phrases.

Play slices from BREAK, a user slot or one built-in piano note. Slicer effects and this engine are separate tools.

**HOME K1-K4:** SRC, DIV, PTCH, DCAY. **Voice cap:** 8, within the shared eight-voice budget.

| Position / label | Musical role |
| --- | --- |
| EDIT1 K1: SRC | BREAK/USR1-3/PIANO recording source. |
| EDIT1 K2: DIV | Equal4/8/16/32, automatic onsets or manual markers. |
| EDIT1 K3: START | Offset of the first selected slice; raw 0-31. |
| EDIT1 K4: PTCH | Slice playback pitch offset, semitones. |
| EDIT2 K1: MODE | ONE shot, GATE by key, or LOOP. |
| EDIT2 K2: REV | Reverse playback. |
| EDIT2 K3: DCAY | Internal decay shaping. |
| EDIT2 K4: TONE | Tone cutoff/filtering. |

Start CHOP. Manual edits apply to user sources; BREAK/PIANO are read-only here. Up to32 slices; some lie outside the27 panel keys without offsets/octave mapping. 

**Factory starting sounds:** CHOP, STUTTER.

**Drone behavior:** No engine-specific natural targets; discrete source/division/mode remain untouched.

<!-- PAGE -->
## 47. DRUM - a voice in the choir

The earthly procession: let a little rhythm into the sanctuary.

Eight synthesized lanes with STD and five visible virtual-analog kits. A part can use DRUM on any track.

**HOME K1-K4:** TUNE, TONE, DECY, SNAP. **Voice cap:** 8, within the shared eight-voice budget.

| Position / label | Musical role |
| --- | --- |
| EDIT1 K1: KIT | Kit; aliases are skipped. Visible STD/80/10/66/55/77. |
| EDIT1 K2: TUNE | Kit tuning index around nominal midpoint. |
| EDIT1 K3: TONE | Kit tone index. |
| EDIT1 K4: DECY | Decay shaping. |
| EDIT2 K1: SNAP | Snare/snappy component treatment. |
| EDIT2 K2: ACC | Accent strength. |
| EDIT2 K3: KICK | Kick character PUNCH/ROUND. |
| EDIT2 K4: DRV | Drive amount. |

EDIT LANES/2 controls all eight levels. General MIDI mapping addresses the lanes; routing uses the track channel. Temporary lane mutes are unsaved. 

**Factory starting sounds:** DRUM KIT.

**Drone behavior:** Deliberately excluded.

<!-- PAGE -->
## 48. FM6: six voices behind one sound

Carriers sing; modulators give them new colours.

FM6 has OPERATOR, OP ENV and OPERATOR2 pages in the EDIT family. These edit the track's patch itself and change SLOT to OWN. Engine macros still sit on top: neutralize MLVL/MRAT/MEG/VMOD/DTUN and select ALG PAT when judging an operator edit in isolation.

| Page | K1 | K2 | K3 | K4 |
| --- | --- | --- | --- | --- |
| OPERATOR | Operator1-6 | COARSE | FINE | LEVEL |
| OP ENV | Operator1-6 | Stage1-4 | RATE | LEVEL |
| OPERATOR2 | Operator1-6 | MODE ratio/fixed | DETUNE | VEL sensitivity |

COARSE and FINE set an operator's frequency; LEVEL controls its strength. In ratio mode the operator follows the played pitch; fixed mode gives it its own frequency. Envelope RATE and LEVEL shape its entrance and departure. DETUNE adds a little disagreement between operators; VEL makes the touch of your hands matter. Hold SAVE for supported operator-edit undo.

**ANALOG FILTER:** TYPE LP/BP/HP, CUT, RES, KTR. TYPE is a common stored field beyond the engine's eight edits; it does not add an EDIT3/4 page.

**DRUM LANES / LANES2:** KICK/SNARE/CLAP/HATCL and HATOP/TOM/RIM/BELL, each raw 0-127/default 127 (0-100%). Temporary held-EDIT lane mutes are separate.

**SLICE SLICES:** K1 marker, K2 position, K3 split-action, K4 join-action; OCT+ confirms selected action. MAN marker data belongs to the user sample slot. Engine DIV determines which source table is active.

<!-- PAGE -->
## 49. FM6 in the Choir Loft

Six operators, one congregation. The editor gives every voice its own candle.


The panel operator pages expose a useful subset; the matched editor exposes the complete single-voice patch. Its six operator blocks have the same fields. Rates/levels are DX7-style indices, not the synth's four common ADSR times. Listen to the sound while editing; changing a modulator and changing a carrier have different consequences.

| Field group | Controls / purpose |
| --- | --- |
| Operator EG rates1-4 and levels1-4 | 0-99 each; four-stage trajectory and speed. |
| Keyboard scaling breakpoint | 0-99; key reference for level scaling. |
| Left/right scaling depths | 0-99; level change either side of breakpoint. |
| Left/right scaling curves | 0-3; linear/exponential, positive/negative curve shapes. |
| Rate scaling | 0-7; envelope speed follows keyboard pitch. |
| Amplitude modulation sensitivity | 0-3; how patch LFO AM affects that operator. |
| Key velocity sensitivity | 0-7; response to note velocity. |
| Output level | 0-99; carrier loudness or modulator influence. |
| Oscillator mode, coarse, fine | Mode0/1 ratio/fixed; coarse0-31, fine0-99. |
| Operator detune | 0-14, centered at7. |
| Pitch EG rates1-4 and levels1-4 | 0-99; patch-wide pitch trajectory. |
| Algorithm, feedback, oscillator sync | Algorithm0-31 (screen1-32), feedback0-7, sync0/1. |
| Patch LFO speed/delay/PM depth/AM depth | 0-99 each; patch-specific modulation separate from track LFO. |
| LFO sync, waveform, pitch sensitivity | Sync0/1; waveform0-5; sensitivity0-7. |
| Transpose | 0-48, centered at24. |
| Voice name | Ten printable characters. |


<!-- PAGE -->
## 50. Updating the hymnbook

The Ritual Room offers an unchecked **Cleanse all user data** option. It permanently erases saved projects, presets, samples and settings, giving you a fresh Evening Vow beginning. Back up your scriptures first. Leaving it unchecked keeps your saved work. You may also cleanse by reinstalling the current offering. Keep power connected until the instrument returns. Transfer lines show KiB sent against package size; rereads can take the count past that size.


Visit the [Ritual Room](https://citadeloftruth.duckdns.org/local/unholyunion/) on desktop Chrome or Edge. Choose an offering, connect one FM-1 and gather your backup before installing. The Apocrypha is the latest experimental offering; Stable appears when a release has been approved.

Start an update only when you can leave USB and power connected until it finishes. A simulation is a rehearsal, not an installation: leave demo mode to connect the instrument. Keep an official recovery package if you have one. If an update is interrupted, read the installer's recovery guidance rather than guessing at boot gestures or formatting an unfamiliar USB disk.

Your computer may call the instrument **BlessedUnion**, its audio **BlessedAudio**, and its MIDI **BlessedMIDI**. Some hosts show the combined name or remember an older one. Choose its audio input to record; MIDI by itself does not carry the sound.

<!-- PAGE -->
## 51. Gratitude, credits and sharing

Our saints are named at the front because their work belongs in the light. Felucca 1.5.1 is by Leo Kuroshita (@kurogedelic), Hügelton Instruments and contributors. Jangada 0.9.4 is by zednaked and contributors, building on Felucca. Cyma Forma and Bambounou's RND synth inspired our invitation to press a button and discover music.

Further gratitude to the upstream community and related projects: SLOOP (isod89), Felucca[Salt] (Chance Roth), Melodee (Kerem Kilic) and X0X (Charles Vestal). Engine and library credits include DaisySP/Rings physical models (MIT), msfa/Dexed (Apache 2.0), Fukiai (MIT), DotGothic16 (OFL), Versilian VSCO-2CE/VCSL samples (CC0), Hügelton drum material (GPL), and the Klatt/Hillenbrand and klattsch voice work. JieLi SDK components retain their own notices.

UnholyUnion firmware and this original manual are shared under **GPL-3.0-only**. The installer links the corresponding firmware source and licence. Original authors retain their notices and credit. M-VAVE/FM-1 and the original project names belong to their respective creators; this is an independent, unaffiliated experiment.

[Editable hymnbook and typesetter](https://citadeloftruth.duckdns.org/local/unholyunion/UnholyUnion-Manual-0.2.3-source.zip) accompany this edition.

Go in peace. Leave the reverb tail.
